export type SupplierClassification =
  | 'Kritik'
  | 'Alternatifi Sınırlı'
  | 'Onaylı'
  | 'Aday';

export type PerformanceTier = 'A' | 'B' | 'C' | 'D';

export type CriterionKey =
  | 'delivery'
  | 'quality'
  | 'commercial'
  | 'customerService'
  | 'ohsEmergency';

export interface SurveyScores {
  delivery: number; // 1-5: Zamanında Teslimat
  quality: number; // 1-5: Kalite Uygunluğu
  commercial: number; // 1-5: Ticari Uyum
  customerService: number; // 1-5: Müşteri Hizmetleri
  ohsEmergency: number; // 1-5: İSG-Acil Durum Uygunluğu
}

export interface EvaluationOutcome {
  tier: PerformanceTier;
  rangeLabel: string;
  resultLabel: string;
  actionLabel: string;
  textColor: string;
}

export interface PerformanceEvaluation {
  id: string;
  date: string; // YYYY-MM-DD
  period: string; // e.g. "2026 Q4"
  evaluator: string;
  scores: SurveyScores;
  totalScore: number; // max 25
  tier: PerformanceTier;
  resultLabel: string;
  actionLabel: string;
  notes: string;
}

export interface Supplier {
  id: string;
  code: string; // e.g. "TDR-1001"
  name: string;
  taxNumber: string; // 10 or 11 digit Vergi No / TCKN
  taxOffice: string;
  category: string;
  classification: SupplierClassification;
  city: string;
  address: string;
  contactPerson: string;
  emails: string[];
  phone: string;
  scores: SurveyScores;
  evaluations: PerformanceEvaluation[];
  createdAt: string;
  updatedAt: string;
  notes?: string;
}

export interface SupplierWithScore extends Supplier {
  totalScore: number;
  tier: PerformanceTier;
  outcome: EvaluationOutcome;
}

export type ActiveView = 'list' | 'scoring' | 'import' | 'analytics';

export type SortField = 'name' | 'code' | 'totalScore' | 'category' | 'classification' | 'updatedAt';
export type SortDirection = 'asc' | 'desc';

export type ExcelFieldKey =
  | 'code'
  | 'name'
  | 'taxNumber'
  | 'taxOffice'
  | 'category'
  | 'classification'
  | 'city'
  | 'address'
  | 'contactPerson'
  | 'emails'
  | 'phone'
  | 'delivery'
  | 'quality'
  | 'commercial'
  | 'customerService'
  | 'ohsEmergency';

export type ColumnMapping = Partial<Record<ExcelFieldKey, string>>;

export type DuplicateStrategy = 'update' | 'skip';

export interface ParsedExcelRow {
  rowIndex: number;
  raw: Record<string, unknown>;
  status: 'valid_new' | 'valid_update' | 'duplicate_skipped' | 'invalid';
  errors: string[];
  normalized?: {
    code?: string;
    name: string;
    taxNumber: string;
    taxOffice: string;
    category: string;
    classification: SupplierClassification;
    city: string;
    address: string;
    contactPerson: string;
    emails: string[];
    phone: string;
    scores: SurveyScores;
  };
  existingSupplierId?: string;
}
