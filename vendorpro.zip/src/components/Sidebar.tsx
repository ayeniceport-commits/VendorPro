import {
  BarChart3,
  Building2,
  ClipboardCheck,
  FileSpreadsheet,
  RotateCcw,
  X,
} from 'lucide-react';
import type { ActiveView } from '../types/supplier';

interface SidebarProps {
  activeView: ActiveView;
  onSelectView: (view: ActiveView) => void;
  supplierCount: number;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onResetDemoData: () => void;
}

const NAV_ITEMS: Array<{
  id: ActiveView;
  label: string;
  description: string;
  icon: typeof Building2;
}> = [
  {
    id: 'list',
    label: 'Tedarikçi Yönetimi',
    description: 'Cari, kategori, adres ve puanlama',
    icon: Building2,
  },
  {
    id: 'scoring',
    label: 'Tedarikçi Puanlama',
    description: '5 soruluk anket (maks. 25 puan)',
    icon: ClipboardCheck,
  },
  {
    id: 'import',
    label: 'Excel İçe Aktarım',
    description: 'Toplu yükleme ve şablon',
    icon: FileSpreadsheet,
  },
  {
    id: 'analytics',
    label: 'Performans Analitiği',
    description: 'Sınıf ve kategori özeti',
    icon: BarChart3,
  },
];

export function Sidebar({
  activeView,
  onSelectView,
  supplierCount,
  mobileOpen,
  onCloseMobile,
  onResetDemoData,
}: SidebarProps) {
  const navContent = (
    <div className="flex h-full flex-col justify-between bg-white border-r border-slate-200">
      <div>
        <div className="flex h-16 items-center justify-between px-5 border-b border-slate-200">
          <div className="min-w-0">
            <span className="block text-base font-bold tracking-tight text-slate-900 truncate">
              Tedarikçi Merkezi
            </span>
            <span className="block text-xs text-slate-500 truncate">
              Satın Alma Modülü · R1
            </span>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Menüyü kapat"
            className="lg:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav aria-label="Tedarikçi modülü gezinme" className="p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 ${
                  isActive
                    ? 'bg-blue-50 text-blue-800'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-blue-700' : 'text-slate-400'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold truncate">{item.label}</span>
                    {item.id === 'list' && (
                      <span className="font-mono text-xs tabular-nums text-slate-500">
                        {supplierCount}
                      </span>
                    )}
                  </div>
                  <span className="block text-xs text-slate-500 truncate">
                    {item.description}
                  </span>
                </div>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-slate-200 space-y-3">
        <div className="text-xs text-slate-500 leading-relaxed">
          <span className="font-medium text-slate-700 block">Kapsam</span>
          <span>Tedarikçi Yönetimi ve Performans Puanlama</span>
        </div>
        <button
          type="button"
          onClick={onResetDemoData}
          className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 hover:text-slate-900 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Örnek Verileri Sıfırla</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-64 shrink-0 h-screen sticky top-0">
        {navContent}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[85vw] h-full z-10">
            {navContent}
          </aside>
        </div>
      )}
    </>
  );
}
