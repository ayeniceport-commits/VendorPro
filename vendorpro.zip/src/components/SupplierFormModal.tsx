import { useEffect, useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import type { Supplier, SupplierClassification } from '../types/supplier';
import {
  CLASSIFICATION_OPTIONS,
  isValidEmail,
  isValidTaxNumber,
} from '../utils/supplierLogic';

export interface SupplierFormValues {
  code: string;
  name: string;
  taxNumber: string;
  taxOffice: string;
  category: string;
  classification: SupplierClassification;
  city: string;
  address: string;
  contactPerson: string;
  emails: string[];
  phone: string;
  notes: string;
}

interface SupplierFormModalProps {
  open: boolean;
  editingSupplier: Supplier | null;
  suggestedCode: string;
  existingSuppliers: Supplier[];
  categories: string[];
  onClose: () => void;
  onSave: (values: SupplierFormValues, editingId?: string) => void;
}

export function SupplierFormModal({
  open,
  editingSupplier,
  suggestedCode,
  existingSuppliers,
  categories,
  onClose,
  onSave,
}: SupplierFormModalProps) {
  const [code, setCode] = useState(suggestedCode);
  const [name, setName] = useState('');
  const [taxNumber, setTaxNumber] = useState('');
  const [taxOffice, setTaxOffice] = useState('');
  const [category, setCategory] = useState(categories[0] ?? 'Genel Tedarik');
  const [customCategory, setCustomCategory] = useState('');
  const [classification, setClassification] =
    useState<SupplierClassification>('Onaylı');
  const [city, setCity] = useState('İstanbul');
  const [address, setAddress] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [emails, setEmails] = useState<string[]>(['']);
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  const [errors, setErrors] = useState<{
    name?: string;
    taxNumber?: string;
    category?: string;
    emails?: string;
  }>({});

  useEffect(() => {
    if (!open) return;
    if (editingSupplier) {
      setCode(editingSupplier.code);
      setName(editingSupplier.name);
      setTaxNumber(editingSupplier.taxNumber);
      setTaxOffice(editingSupplier.taxOffice);
      if (categories.includes(editingSupplier.category)) {
        setCategory(editingSupplier.category);
        setCustomCategory('');
      } else {
        setCategory('__CUSTOM__');
        setCustomCategory(editingSupplier.category);
      }
      setClassification(editingSupplier.classification);
      setCity(editingSupplier.city);
      setAddress(editingSupplier.address === '-' ? '' : editingSupplier.address);
      setContactPerson(
        editingSupplier.contactPerson === '-' ? '' : editingSupplier.contactPerson
      );
      setEmails(
        editingSupplier.emails.length > 0 ? [...editingSupplier.emails] : ['']
      );
      setPhone(editingSupplier.phone === '-' ? '' : editingSupplier.phone);
      setNotes(editingSupplier.notes ?? '');
    } else {
      setCode(suggestedCode);
      setName('');
      setTaxNumber('');
      setTaxOffice('');
      setCategory(categories[0] ?? 'Genel Tedarik');
      setCustomCategory('');
      setClassification('Onaylı');
      setCity('İstanbul');
      setAddress('');
      setContactPerson('');
      setEmails(['']);
      setPhone('');
      setNotes('');
    }
    setErrors({});
  }, [open, editingSupplier, suggestedCode, categories]);

  if (!open) return null;

  const handleAddEmailField = () => {
    setEmails((prev) => [...prev, '']);
  };

  const handleEmailChange = (index: number, value: string) => {
    setEmails((prev) => prev.map((item, i) => (i === index ? value : item)));
  };

  const handleRemoveEmail = (index: number) => {
    setEmails((prev) => {
      if (prev.length <= 1) return [''];
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: typeof errors = {};

    if (!name.trim()) {
      nextErrors.name = 'Firma unvanı zorunludur.';
    }
    const cleanTax = taxNumber.replace(/\s+/g, '');
    if (!cleanTax) {
      nextErrors.taxNumber = 'Vergi numarası zorunludur.';
    } else if (!isValidTaxNumber(cleanTax)) {
      nextErrors.taxNumber = 'Vergi No 10 veya 11 haneli rakam olmalıdır.';
    } else {
      const duplicate = existingSuppliers.find(
        (s) => s.taxNumber === cleanTax && s.id !== editingSupplier?.id
      );
      if (duplicate) {
        nextErrors.taxNumber = `Bu Vergi No zaten "${duplicate.name}" için kayıtlı.`;
      }
    }

    const resolvedCategory =
      category === '__CUSTOM__' ? customCategory.trim() : category;
    if (!resolvedCategory) {
      nextErrors.category = 'Kategori adı belirtilmelidir.';
    }

    const nonEmptyEmails = emails.map((m) => m.trim()).filter(Boolean);
    const invalidEmails = nonEmptyEmails.filter((m) => !isValidEmail(m));
    if (invalidEmails.length > 0) {
      nextErrors.emails = `Geçersiz e-posta adresi: ${invalidEmails.join(', ')}`;
    }

    const uniqueEmails: string[] = [];
    const seen = new Set<string>();
    for (const m of nonEmptyEmails) {
      const lower = m.toLowerCase();
      if (!seen.has(lower)) {
        seen.add(lower);
        uniqueEmails.push(m);
      }
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    onSave(
      {
        code: code.trim() || suggestedCode,
        name: name.trim(),
        taxNumber: cleanTax,
        taxOffice: taxOffice.trim() || 'Belirtilmedi',
        category: resolvedCategory,
        classification,
        city: city.trim() || 'İstanbul',
        address: address.trim() || '-',
        contactPerson: contactPerson.trim() || '-',
        emails: uniqueEmails,
        phone: phone.trim() || '-',
        notes: notes.trim(),
      },
      editingSupplier?.id
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="supplier-modal-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-2xl bg-white border border-slate-200 rounded-xl max-h-[92vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between z-10">
          <h2
            id="supplier-modal-title"
            className="text-base font-semibold text-slate-900"
          >
            {editingSupplier ? 'Tedarikçi Bilgilerini Güncelle' : 'Yeni Tedarikçi Ekle'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Formu kapat"
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="sup-code"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Tedarikçi Kodu
              </label>
              <input
                id="sup-code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div>
              <label
                htmlFor="sup-classification"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Tedarikçi Sınıflandırması
              </label>
              <select
                id="sup-classification"
                value={classification}
                onChange={(e) =>
                  setClassification(e.target.value as SupplierClassification)
                }
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              >
                {CLASSIFICATION_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="sup-name"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Firma Unvanı <span className="text-red-600">*</span>
              </label>
              <input
                id="sup-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Örn: Marmara Metal San. ve Tic. A.Ş."
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
              {errors.name && (
                <p role="alert" className="mt-1 text-xs text-red-700">
                  {errors.name}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="sup-tax"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Vergi No / TCKN <span className="text-red-600">*</span>
              </label>
              <input
                id="sup-tax"
                type="text"
                value={taxNumber}
                onChange={(e) => setTaxNumber(e.target.value)}
                placeholder="10 haneli VKN"
                className="w-full px-3 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
              {errors.taxNumber && (
                <p role="alert" className="mt-1 text-xs text-red-700">
                  {errors.taxNumber}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="sup-tax-office"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Vergi Dairesi
              </label>
              <input
                id="sup-tax-office"
                type="text"
                value={taxOffice}
                onChange={(e) => setTaxOffice(e.target.value)}
                placeholder="Örn: Gebze İhtisas V.D."
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div>
              <label
                htmlFor="sup-category"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Kategori
              </label>
              <select
                id="sup-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
                <option value="__CUSTOM__">Yeni Kategori Ekle...</option>
              </select>
              {category === '__CUSTOM__' && (
                <input
                  type="text"
                  aria-label="Özel kategori adı"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  placeholder="Kategori adını yazın..."
                  className="mt-2 w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              )}
              {errors.category && (
                <p role="alert" className="mt-1 text-xs text-red-700">
                  {errors.category}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="sup-city"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Şehir
              </label>
              <input
                id="sup-city"
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="sup-address"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Adres
              </label>
              <input
                id="sup-address"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="OSB, cadde, sokak, kapı no ve ilçe bilgisi..."
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div>
              <label
                htmlFor="sup-contact"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Yetkili Kişi
              </label>
              <input
                id="sup-contact"
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="Ad Soyad"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div>
              <label
                htmlFor="sup-phone"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Yetkili İletişim (Telefon)
              </label>
              <input
                id="sup-phone"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+90 212 ..."
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            {/* Multiple Email Addresses */}
            <div className="sm:col-span-2 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-700">
                  E-posta Adresleri (Birden fazla eklenebilir)
                </span>
                <button
                  type="button"
                  onClick={handleAddEmailField}
                  className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:text-blue-800"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>E-posta Ekle</span>
                </button>
              </div>
              <div className="space-y-2">
                {emails.map((emailVal, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="email"
                      aria-label={`E-posta adresi ${idx + 1}`}
                      value={emailVal}
                      onChange={(e) => handleEmailChange(idx, e.target.value)}
                      placeholder={
                        idx === 0
                          ? 'birincil@firma.com'
                          : `ikincil-${idx + 1}@firma.com`
                      }
                      className="flex-1 px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                    />
                    {emails.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveEmail(idx)}
                        aria-label={`E-posta adresi ${idx + 1} kaldır`}
                        className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              {errors.emails && (
                <p role="alert" className="text-xs text-red-700">
                  {errors.emails}
                </p>
              )}
            </div>

            <div className="sm:col-span-2">
              <label
                htmlFor="sup-notes"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Notlar
              </label>
              <textarea
                id="sup-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800"
            >
              {editingSupplier ? 'Değişiklikleri Kaydet' : 'Tedarikçiyi Kaydet'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
