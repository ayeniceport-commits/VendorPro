import { useEffect, useState } from 'react';
import { Check, TrendingUp, X } from 'lucide-react';
import type { SupplierWithScore, SurveyScores } from '../types/supplier';
import {
  EVALUATION_SCALE_TABLE,
  RATING_SCALE_LABELS,
  SURVEY_CRITERIA,
  calculateTotalScore,
  getEvaluationOutcome,
} from '../utils/supplierLogic';

interface SupplierScoringDrawerProps {
  supplier: SupplierWithScore | null;
  onClose: () => void;
  onOpenHistory: (supplierId: string) => void;
  onSaveEvaluation: (
    supplierId: string,
    payload: {
      date: string;
      period: string;
      evaluator: string;
      scores: SurveyScores;
      notes: string;
    }
  ) => void;
}

export function SupplierScoringDrawer({
  supplier,
  onClose,
  onOpenHistory,
  onSaveEvaluation,
}: SupplierScoringDrawerProps) {
  const [scores, setScores] = useState<SurveyScores>({
    delivery: 3,
    quality: 3,
    commercial: 3,
    customerService: 3,
    ohsEmergency: 3,
  });
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [period, setPeriod] = useState('2026 Q4');
  const [evaluator, setEvaluator] = useState('Satın Alma Değerlendirme Komitesi');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (supplier) {
      setScores({ ...supplier.scores });
      setNotes('');
      setError(null);
    }
  }, [supplier?.id]);

  if (!supplier) return null;

  const totalScore = calculateTotalScore(scores);
  const outcome = getEvaluationOutcome(totalScore);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date.trim() || !period.trim() || !evaluator.trim()) {
      setError('Değerlendirme tarihi, dönemi ve değerlendirici adı zorunludur.');
      return;
    }
    onSaveEvaluation(supplier.id, {
      date: date.trim(),
      period: period.trim(),
      evaluator: evaluator.trim(),
      scores,
      notes: notes.trim() || `${outcome.resultLabel} (${totalScore}/25) — ${outcome.actionLabel}`,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="scoring-drawer-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-2xl bg-white h-full overflow-y-auto border-l border-slate-200 flex flex-col justify-between">
        <div>
          <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-start justify-between gap-4 z-10">
            <div className="min-w-0">
              <div className="text-xs font-mono text-slate-500 tabular-nums">
                {supplier.code} · {supplier.classification}
              </div>
              <h2
                id="scoring-drawer-title"
                className="mt-0.5 text-base font-semibold text-slate-900"
              >
                Tedarikçi Puanlama Anketi — {supplier.name}
              </h2>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenHistory(supplier.id);
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md whitespace-nowrap"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>GEÇMİŞ PERFORMANS</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                aria-label="Puanlama anketini kapat"
                className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <form id="drawer-survey-form" onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Live Score & Action Banner */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <span className="block text-xs text-slate-500">
                  Anket Toplam Puanı (Maks. 25)
                </span>
                <div className="mt-1 flex items-baseline gap-2.5">
                  <span
                    data-testid="drawer-total-score"
                    className="font-mono text-2xl font-bold tabular-nums text-slate-900"
                  >
                    {totalScore} / 25
                  </span>
                  <span className={`text-sm font-semibold ${outcome.textColor}`}>
                    ({outcome.tier}) {outcome.resultLabel}
                  </span>
                </div>
              </div>
              <div className="text-left sm:text-right">
                <span className="block text-xs text-slate-500">Önerilen Aksiyon</span>
                <span className="mt-1 block text-sm font-semibold text-slate-900">
                  {outcome.actionLabel}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="drawer-eval-period"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Değerlendirme Dönemi
                </label>
                <input
                  id="drawer-eval-period"
                  type="text"
                  value={period}
                  onChange={(e) => setPeriod(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              </div>
              <div>
                <label
                  htmlFor="drawer-eval-date"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Değerlendirme Tarihi
                </label>
                <input
                  id="drawer-eval-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              </div>
              <div className="sm:col-span-2">
                <label
                  htmlFor="drawer-eval-evaluator"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Değerlendiren Kişi / Birim
                </label>
                <input
                  id="drawer-eval-evaluator"
                  type="text"
                  value={evaluator}
                  onChange={(e) => setEvaluator(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              </div>
            </div>

            {/* 5 Questions (1-5 rating each) */}
            <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
              {SURVEY_CRITERIA.map((criterion) => {
                const currentVal = scores[criterion.key];
                return (
                  <div key={criterion.key} className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-sm font-semibold text-slate-900">
                          {criterion.order}. {criterion.label}
                        </span>
                        <p className="mt-0.5 text-xs text-slate-500">
                          {criterion.question}
                        </p>
                      </div>
                      <span className="font-mono text-xs font-semibold tabular-nums text-slate-700 whitespace-nowrap">
                        {currentVal} / 5 · {RATING_SCALE_LABELS[currentVal]}
                      </span>
                    </div>

                    <div
                      role="group"
                      aria-label={`${criterion.label} puanı`}
                      className="grid grid-cols-5 gap-2"
                    >
                      {[1, 2, 3, 4, 5].map((num) => {
                        const active = currentVal === num;
                        return (
                          <button
                            key={num}
                            type="button"
                            onClick={() =>
                              setScores((prev) => ({
                                ...prev,
                                [criterion.key]: num,
                              }))
                            }
                            aria-pressed={active}
                            className={`py-2 px-2 rounded-lg text-xs font-medium border ${
                              active
                                ? 'bg-blue-700 text-white border-blue-700'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <span className="font-mono font-semibold">{num}</span>
                            <span className="hidden sm:inline ml-1 font-normal">
                              · {RATING_SCALE_LABELS[num]}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div>
              <label
                htmlFor="drawer-eval-notes"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Değerlendirme Notu
              </label>
              <textarea
                id="drawer-eval-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Anket sonucu veya aksiyon açıklaması..."
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            {/* Reference Scale Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700">
                Derecelendirme ve Aksiyon Ölçeği
              </div>
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 px-4 font-medium">Toplam Puan</th>
                    <th className="py-2 px-3 font-medium">Değerlendirme Sonucu</th>
                    <th className="py-2 px-4 font-medium">Aksiyon</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {EVALUATION_SCALE_TABLE.map((row) => {
                    const isCurrent = row.tier === outcome.tier;
                    return (
                      <tr
                        key={row.tier}
                        className={isCurrent ? 'bg-blue-50/70' : 'bg-white'}
                      >
                        <td className={`py-2 px-4 font-mono font-semibold tabular-nums ${row.textColor}`}>
                          ({row.tier}) {row.rangeLabel}
                        </td>
                        <td className="py-2 px-3 font-medium text-slate-900">
                          {row.resultLabel}
                        </td>
                        <td className="py-2 px-4 text-slate-700">
                          {row.actionLabel}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {error && (
              <p role="alert" className="text-xs font-medium text-red-700">
                {error}
              </p>
            )}
          </form>
        </div>

        <div className="sticky bottom-0 bg-white border-t border-slate-200 px-6 py-4 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            İptal
          </button>
          <button
            type="submit"
            form="drawer-survey-form"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Puanlamayı Kaydet ({totalScore}/25)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
