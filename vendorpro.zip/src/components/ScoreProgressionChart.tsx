import type { PerformanceEvaluation, PerformanceTier } from '../types/supplier';
import { formatShortTrDate } from '../utils/supplierLogic';

interface ScoreProgressionChartProps {
  evaluations: PerformanceEvaluation[];
  compact?: boolean;
  selectedEvalId?: string | null;
  onSelectEvaluation?: (evalId: string) => void;
}

const TIER_POINT_HEX: Record<PerformanceTier, string> = {
  A: '#047857', // emerald-700
  B: '#1d4ed8', // blue-700
  C: '#b45309', // amber-700
  D: '#b91c1c', // red-700
};

export function ScoreProgressionChart({
  evaluations,
  compact = false,
  selectedEvalId,
  onSelectEvaluation,
}: ScoreProgressionChartProps) {
  if (evaluations.length === 0) {
    return (
      <div className="py-5 px-4 bg-slate-50 border border-slate-200 rounded-lg text-center text-xs text-slate-500">
        Tarih bazlı puan gelişimi için henüz değerlendirme kaydı bulunmuyor.
      </div>
    );
  }

  const width = compact ? 420 : 660;
  const height = compact ? 138 : 230;
  const padLeft = compact ? 28 : 38;
  const padRight = compact ? 24 : 32;
  const padTop = compact ? 20 : 24;
  const padBottom = compact ? 34 : 46;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const toY = (score: number) => {
    const clamped = Math.max(0, Math.min(25, score));
    return padTop + plotH - (clamped / 25) * plotH;
  };

  const count = evaluations.length;
  const toX = (idx: number) => {
    if (count === 1) return padLeft + plotW / 2;
    return padLeft + (idx / (count - 1)) * plotW;
  };

  const points = evaluations.map((ev, idx) => ({
    ev,
    x: toX(idx),
    y: toY(ev.totalScore),
    color: TIER_POINT_HEX[ev.tier],
  }));

  const linePath = points
    .map((pt, idx) => `${idx === 0 ? 'M' : 'L'} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`)
    .join(' ');

  const areaPath =
    points.length >= 2
      ? `${linePath} L ${points[points.length - 1].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} L ${points[0].x.toFixed(1)} ${(padTop + plotH).toFixed(1)} Z`
      : '';

  const thresholds = [
    { value: 21, label: '21 (A)', stroke: '#10b981' },
    { value: 16, label: '16 (B)', stroke: '#3b82f6' },
    { value: 11, label: '11 (C)', stroke: '#f59e0b' },
  ];

  return (
    <div className="w-full" data-testid={compact ? 'compact-progression-chart' : 'full-progression-chart'}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        role="img"
        aria-label="Tarih bazlı tedarikçi puan gelişim grafiği"
      >
        <defs>
          <linearGradient id={compact ? 'scoreAreaCompact' : 'scoreAreaFull'} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1d4ed8" stopOpacity="0.14" />
            <stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.01" />
          </linearGradient>
        </defs>

        {/* Baseline 0 and Max 25 */}
        <line
          x1={padLeft}
          y1={toY(25)}
          x2={width - padRight}
          y2={toY(25)}
          stroke="#e2e8f0"
          strokeWidth="1"
        />
        <line
          x1={padLeft}
          y1={toY(0)}
          x2={width - padRight}
          y2={toY(0)}
          stroke="#cbd5e1"
          strokeWidth="1"
        />
        <text
          x={padLeft - 6}
          y={toY(25) + 3}
          textAnchor="end"
          fontSize={compact ? '9' : '10'}
          fill="#64748b"
          fontFamily="ui-monospace, monospace"
        >
          25
        </text>
        <text
          x={padLeft - 6}
          y={toY(0) + 3}
          textAnchor="end"
          fontSize={compact ? '9' : '10'}
          fill="#64748b"
          fontFamily="ui-monospace, monospace"
        >
          0
        </text>

        {/* Threshold lines (11, 16, 21) */}
        {thresholds.map((t) => (
          <g key={t.value}>
            <line
              x1={padLeft}
              y1={toY(t.value)}
              x2={width - padRight}
              y2={toY(t.value)}
              stroke={t.stroke}
              strokeOpacity="0.35"
              strokeWidth="1"
              strokeDasharray="3 3"
            />
            {!compact && (
              <text
                x={padLeft - 6}
                y={toY(t.value) + 3}
                textAnchor="end"
                fontSize="10"
                fill="#64748b"
                fontFamily="ui-monospace, monospace"
              >
                {t.value}
              </text>
            )}
          </g>
        ))}

        {/* Area fill */}
        {areaPath && (
          <path
            d={areaPath}
            fill={`url(#${compact ? 'scoreAreaCompact' : 'scoreAreaFull'})`}
          />
        )}

        {/* Progression line */}
        {points.length >= 2 && (
          <path
            d={linePath}
            fill="none"
            stroke="#1d4ed8"
            strokeWidth={compact ? '2' : '2.5'}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Evaluation points */}
        {points.map(({ ev, x, y, color }) => {
          const isSelected = selectedEvalId === ev.id;
          const interactive = Boolean(onSelectEvaluation);
          const showDateBelow = !compact || count <= 5;
          return (
            <g
              key={ev.id}
              onClick={interactive ? () => onSelectEvaluation?.(ev.id) : undefined}
              className={interactive ? 'cursor-pointer' : undefined}
            >
              {isSelected && (
                <circle
                  cx={x}
                  cy={y}
                  r={compact ? 7 : 9}
                  fill={color}
                  fillOpacity="0.16"
                />
              )}
              <circle
                cx={x}
                cy={y}
                r={compact ? 4 : isSelected ? 6 : 5}
                fill="#ffffff"
                stroke={color}
                strokeWidth={compact ? '2.2' : '2.5'}
              />
              <text
                x={x}
                y={y - (compact ? 8 : 11)}
                textAnchor="middle"
                fontSize={compact ? '10' : '11'}
                fontWeight="700"
                fill="#0f172a"
                fontFamily="ui-monospace, monospace"
              >
                {ev.totalScore}
              </text>
              <text
                x={x}
                y={padTop + plotH + (compact ? 14 : 17)}
                textAnchor="middle"
                fontSize={compact ? '9.5' : '10.5'}
                fontWeight="600"
                fill="#334155"
              >
                {ev.period}
              </text>
              {showDateBelow && (
                <text
                  x={x}
                  y={padTop + plotH + (compact ? 25 : 31)}
                  textAnchor="middle"
                  fontSize={compact ? '8.5' : '9.5'}
                  fill="#64748b"
                  fontFamily="ui-monospace, monospace"
                >
                  {formatShortTrDate(ev.date)}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
