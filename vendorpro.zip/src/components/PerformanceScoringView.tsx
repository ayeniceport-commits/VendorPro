import { useEffect, useState } from 'react';
import { Check, TrendingUp } from 'lucide-react';
import type { SupplierWithScore, SurveyScores } from '../types/supplier';
import {
  CLASSIFICATION_TEXT_COLOR,
  EVALUATION_SCALE_TABLE,
  RATING_SCALE_LABELS,
  SURVEY_CRITERIA,
  calculateTotalScore,
  computeScoreProgression,
  formatShortTrDate,
  getEvaluationOutcome,
} from '../utils/supplierLogic';
import { ScoreProgressionChart } from './ScoreProgressionChart';

interface PerformanceScoringViewProps {
  suppliers: SupplierWithScore[];
  initialSupplierId?: string | null;
  onOpenHistory: (supplierId: string) => void;
  onSaveEvaluation: (
    supplierId: string,
    payload: {
      date: string;
      period: string;
      evaluator: string;
      scores: SurveyScores;
      notes: string;
    }
  ) => void;
}

export function PerformanceScoringView({
  suppliers,
  initialSupplierId,
  onOpenHistory,
  onSaveEvaluation,
}: PerformanceScoringViewProps) {
  const [selectedId, setSelectedId] = useState<string>(
    initialSupplierId || suppliers[0]?.id || ''
  );

  const selectedSupplier =
    suppliers.find((s) => s.id === selectedId) || suppliers[0] || null;

  const [scores, setScores] = useState<SurveyScores>(
    selectedSupplier?.scores ?? {
      delivery: 3,
      quality: 3,
      commercial: 3,
      customerService: 3,
      ohsEmergency: 3,
    }
  );
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [period, setPeriod] = useState('2026 Q4');
  const [evaluator, setEvaluator] = useState('Satın Alma Değerlendirme Komitesi');
  const [notes, setNotes] = useState('');
  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (initialSupplierId && suppliers.some((s) => s.id === initialSupplierId)) {
      setSelectedId(initialSupplierId);
    }
  }, [initialSupplierId, suppliers]);

  useEffect(() => {
    if (selectedSupplier) {
      setScores({ ...selectedSupplier.scores });
      setNotes('');
      setFormError(null);
    }
  }, [selectedSupplier?.id]);

  const totalScore = calculateTotalScore(scores);
  const outcome = getEvaluationOutcome(totalScore);

  const handleScoreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplier) return;
    if (!date.trim() || !period.trim() || !evaluator.trim()) {
      setFormError('Değerlendirme tarihi, dönemi ve değerlendirici adı zorunludur.');
      return;
    }

    setFormError(null);
    onSaveEvaluation(selectedSupplier.id, {
      date: date.trim(),
      period: period.trim(),
      evaluator: evaluator.trim(),
      scores,
      notes:
        notes.trim() ||
        `${outcome.resultLabel} (${totalScore}/25) — ${outcome.actionLabel}`,
    });
    setSavedFeedback(
      `${selectedSupplier.name} için ${period.trim()} (${formatShortTrDate(date.trim())}) anket puanı kaydedildi: ${totalScore}/25 (${outcome.tier}) · ${outcome.resultLabel}.`
    );
    setNotes('');
    setTimeout(() => setSavedFeedback(null), 4500);
  };

  if (suppliers.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <p className="text-sm font-medium text-slate-900">
          Puanlanacak tedarikçi bulunamadı
        </p>
        <p className="mt-1 text-sm text-slate-500">
          Önce Tedarikçi Listesi veya Excel İçe Aktarım üzerinden tedarikçi ekleyin.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
      {/* Left 7 Cols: 5-Question Survey Form */}
      <section className="xl:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex flex-wrap md:flex-nowrap items-start justify-between gap-4 pb-5 border-b border-slate-200">
          <div className="flex-1 min-w-0">
            <h2 className="text-base font-semibold text-slate-900">
              Tedarikçi Puanlama Anketi (5 Soru · Maks. 25 Puan)
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Her kriteri 1 ile 5 arasında puanlayın; toplam skor, değerlendirme
              sonucu ve aksiyon otomatik belirlenir.
            </p>
          </div>
          <div className="text-left md:text-right shrink-0">
            <span className="block text-xs text-slate-500">Toplam Puan</span>
            <div className="mt-0.5 flex items-baseline md:justify-end gap-2">
              <span
                data-testid="live-weighted-score"
                className="font-mono text-2xl font-bold tabular-nums text-slate-900"
              >
                {totalScore} / 25
              </span>
              <span className={`text-sm font-semibold ${outcome.textColor}`}>
                ({outcome.tier}) {outcome.resultLabel}
              </span>
            </div>
            <span className="block text-xs text-slate-600">
              Aksiyon: {outcome.actionLabel}
            </span>
          </div>
        </div>

        <form onSubmit={handleScoreSubmit} className="mt-5 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label
                htmlFor="eval-supplier-select"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Değerlendirilecek Tedarikçi
              </label>
              <select
                id="eval-supplier-select"
                value={selectedSupplier?.id ?? ''}
                onChange={(e) => setSelectedId(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              >
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code} — {s.name} [{s.classification}] (Mevcut: {s.totalScore}/25)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="eval-period"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Değerlendirme Dönemi
              </label>
              <input
                id="eval-period"
                type="text"
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
                placeholder="Örn: 2026 Q4"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div>
              <label
                htmlFor="eval-date"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Değerlendirme Tarihi
              </label>
              <input
                id="eval-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>

            <div className="md:col-span-2">
              <label
                htmlFor="eval-evaluator"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Değerlendiren Kişi / Birim
              </label>
              <input
                id="eval-evaluator"
                type="text"
                value={evaluator}
                onChange={(e) => setEvaluator(e.target.value)}
                placeholder="Örn: Selin Aksoy (Kalite)"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl">
            {SURVEY_CRITERIA.map((criterion) => {
              const currentVal = scores[criterion.key];
              return (
                <div key={criterion.key} className="p-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-sm font-semibold text-slate-900">
                        {criterion.order}. {criterion.label}
                      </span>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {criterion.question}
                      </p>
                    </div>
                    <span className="font-mono text-xs font-semibold tabular-nums text-slate-700 whitespace-nowrap">
                      {currentVal} / 5 · {RATING_SCALE_LABELS[currentVal]}
                    </span>
                  </div>

                  <div
                    role="group"
                    aria-label={`${criterion.label} puanı`}
                    className="grid grid-cols-5 gap-2"
                  >
                    {[1, 2, 3, 4, 5].map((num) => {
                      const active = currentVal === num;
                      return (
                        <button
                          key={num}
                          type="button"
                          onClick={() =>
                            setScores((prev) => ({
                              ...prev,
                              [criterion.key]: num,
                            }))
                          }
                          aria-pressed={active}
                          className={`py-2 px-2 rounded-lg text-xs font-medium border ${
                            active
                              ? 'bg-blue-700 text-white border-blue-700'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <span className="font-mono font-semibold">{num}</span>
                          <span className="hidden sm:inline ml-1 font-normal">
                            · {RATING_SCALE_LABELS[num]}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          <div>
            <label
              htmlFor="eval-notes"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Denetim ve Değerlendirme Notu
            </label>
            <textarea
              id="eval-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Teslimat performansı, kalite bulguları veya İSG aksiyon notları..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
            />
          </div>

          {formError && (
            <p role="alert" className="text-xs font-medium text-red-700">
              {formError}
            </p>
          )}

          {savedFeedback && (
            <div
              role="status"
              className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-medium text-emerald-800"
            >
              <Check className="w-4 h-4 shrink-0" />
              <span>{savedFeedback}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-1">
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors whitespace-nowrap"
            >
              Anket Puanlamasını Kaydet ({totalScore}/25)
            </button>
          </div>
        </form>
      </section>

      {/* Right 5 Cols: Evaluation Scale Reference + Selected Supplier Info & History */}
      <div className="xl:col-span-5 space-y-6">
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-base font-semibold text-slate-900">
              Puanlama Derecelendirme Tablosu
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              5 soru × (1–5 puan) = Toplam maks. 25 puan üzerinden otomatik aksiyon
            </p>
          </div>
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500">
                <th className="py-2.5 px-4 font-medium">Toplam Puan</th>
                <th className="py-2.5 px-3 font-medium">Değerlendirme Sonucu</th>
                <th className="py-2.5 px-4 font-medium">Aksiyon</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {EVALUATION_SCALE_TABLE.map((row) => {
                const isCurrent = row.tier === outcome.tier;
                return (
                  <tr
                    key={row.tier}
                    className={isCurrent ? 'bg-blue-50/70' : 'bg-white'}
                  >
                    <td
                      className={`py-3 px-4 font-mono font-semibold tabular-nums whitespace-nowrap ${row.textColor}`}
                    >
                      ({row.tier}) {row.rangeLabel}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-900">
                      {row.resultLabel}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{row.actionLabel}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>

        {selectedSupplier && (() => {
          const progression = computeScoreProgression(selectedSupplier.evaluations);
          const recentDescending = [...progression.chronological].reverse();
          return (
            <section className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="pb-3 border-b border-slate-200 flex items-center justify-between gap-2">
                <h2 className="text-base font-semibold text-slate-900">
                  Seçili Tedarikçi Özeti
                </h2>
                <span
                  className={`text-xs font-semibold ${
                    CLASSIFICATION_TEXT_COLOR[selectedSupplier.classification]
                  }`}
                >
                  {selectedSupplier.classification}
                </span>
              </div>
              <div className="mt-3 text-xs text-slate-600 space-y-1">
                <div className="font-medium text-slate-900">
                  {selectedSupplier.category} · {selectedSupplier.city}
                </div>
                <div>Yetkili: {selectedSupplier.contactPerson}</div>
                <div>
                  E-posta:{' '}
                  {selectedSupplier.emails.length > 0
                    ? selectedSupplier.emails.join(', ')
                    : '-'}
                </div>
              </div>

              {/* Focused History Heading + GEÇMİŞ PERFORMANS Button + Date-Based Progression Chart */}
              <h3 className="mt-5 text-xs font-semibold text-slate-900 pb-2 border-b border-slate-200 flex items-center justify-between gap-2">
                <span>
                  Son Değerlendirme Geçmişi ({progression.count})
                  {progression.deltaFromPrevious !== null && (
                    <span
                      className={`ml-2 font-mono font-semibold tabular-nums ${
                        progression.deltaFromPrevious > 0
                          ? 'text-emerald-700'
                          : progression.deltaFromPrevious < 0
                            ? 'text-red-700'
                            : 'text-slate-500'
                      }`}
                    >
                      {progression.deltaFromPrevious > 0
                        ? `+${progression.deltaFromPrevious}`
                        : progression.deltaFromPrevious}{' '}
                      puan
                    </span>
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => onOpenHistory(selectedSupplier.id)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md whitespace-nowrap shrink-0"
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>GEÇMİŞ PERFORMANS</span>
                </button>
              </h3>

              <div className="mt-3">
                <ScoreProgressionChart evaluations={progression.chronological} compact />
              </div>

              {recentDescending.length > 0 ? (
                <ul className="divide-y divide-slate-200 mt-3">
                  {recentDescending.slice(0, 4).map((ev) => {
                    const chronoIdx = progression.chronological.findIndex((item) => item.id === ev.id);
                    const prevEv = chronoIdx > 0 ? progression.chronological[chronoIdx - 1] : null;
                    const stepDelta = prevEv ? ev.totalScore - prevEv.totalScore : null;
                    return (
                      <li key={ev.id} className="py-3">
                        <div className="flex items-center justify-between gap-2">
                          <div className="text-xs text-slate-500">
                            <span className="font-semibold text-slate-800">
                              {ev.period}
                            </span>
                            <span className="mx-1.5" aria-hidden="true">
                              ·
                            </span>
                            <span className="font-mono tabular-nums">
                              {formatShortTrDate(ev.date)}
                            </span>
                          </div>
                          <div className="font-mono text-xs font-semibold tabular-nums text-slate-900">
                            {ev.totalScore}/25 ({ev.tier})
                            {stepDelta !== null && stepDelta !== 0 && (
                              <span
                                className={`ml-1.5 ${
                                  stepDelta > 0 ? 'text-emerald-700' : 'text-red-700'
                                }`}
                              >
                                {stepDelta > 0 ? `+${stepDelta}` : stepDelta}
                              </span>
                            )}
                            <span className="font-sans font-normal text-slate-500 ml-1">
                              · {ev.resultLabel}
                            </span>
                          </div>
                        </div>
                        <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                          {ev.notes}
                        </p>
                        <p className="mt-1 text-xs text-slate-400">
                          {ev.evaluator} · Aksiyon: {ev.actionLabel}
                        </p>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="mt-3 text-xs text-slate-500">
                  Bu tedarikçi için henüz geçmiş değerlendirme kaydı bulunmuyor.
                </p>
              )}
            </section>
          );
        })()}
      </div>
    </div>
  );
}
