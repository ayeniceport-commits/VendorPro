import { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Upload,
} from 'lucide-react';
import type {
  ColumnMapping,
  DuplicateStrategy,
  ExcelFieldKey,
  ParsedExcelRow,
  Supplier,
} from '../types/supplier';
import {
  downloadSupplierExcelTemplate,
  readExcelFile,
  type ExcelWorkbookData,
} from '../utils/excelService';
import {
  EXCEL_FIELD_DEFINITIONS,
  autoDetectColumnMapping,
  parseExcelRows,
} from '../utils/supplierLogic';

interface ExcelImportViewProps {
  existingSuppliers: Supplier[];
  onCommitImport: (
    rows: ParsedExcelRow[],
    duplicateStrategy: DuplicateStrategy
  ) => { added: number; updated: number; skipped: number };
  onGoToList: () => void;
}

export function ExcelImportView({
  existingSuppliers,
  onCommitImport,
  onGoToList,
}: ExcelImportViewProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [workbook, setWorkbook] = useState<ExcelWorkbookData | null>(null);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [mapping, setMapping] = useState<ColumnMapping>({});
  const [duplicateStrategy, setDuplicateStrategy] =
    useState<DuplicateStrategy>('update');
  const [readError, setReadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [importResult, setImportResult] = useState<{
    added: number;
    updated: number;
    skipped: number;
  } | null>(null);

  const currentSheetData =
    workbook && selectedSheet ? workbook.sheets[selectedSheet] : null;

  const parsedRows = useMemo(() => {
    if (!currentSheetData) return [];
    return parseExcelRows(
      currentSheetData.rows,
      mapping,
      existingSuppliers,
      duplicateStrategy
    );
  }, [currentSheetData, mapping, existingSuppliers, duplicateStrategy]);

  const summary = useMemo(() => {
    let validNew = 0;
    let validUpdate = 0;
    let skipped = 0;
    let invalid = 0;
    for (const row of parsedRows) {
      if (row.status === 'valid_new') validNew += 1;
      else if (row.status === 'valid_update') validUpdate += 1;
      else if (row.status === 'duplicate_skipped') skipped += 1;
      else invalid += 1;
    }
    return {
      total: parsedRows.length,
      validNew,
      validUpdate,
      skipped,
      invalid,
      actionable: validNew + validUpdate,
    };
  }, [parsedRows]);

  const handleFile = async (file: File) => {
    setReadError(null);
    setImportResult(null);
    try {
      const data = await readExcelFile(file);
      if (data.sheetNames.length === 0) {
        setReadError('Excel dosyasında okunabilir çalışma sayfası bulunamadı.');
        return;
      }
      const firstSheet = data.sheetNames[0];
      const sheetObj = data.sheets[firstSheet];
      if (!sheetObj || sheetObj.rows.length === 0) {
        setReadError('Seçilen Excel sayfasında veri satırı bulunamadı.');
        return;
      }
      setWorkbook(data);
      setSelectedSheet(firstSheet);
      setMapping(autoDetectColumnMapping(sheetObj.headers));
    } catch {
      setReadError(
        'Dosya okunamadı. Lütfen geçerli bir .xlsx, .xls veya .csv dosyası seçin.'
      );
    }
  };

  const handleSheetChange = (sheetName: string) => {
    if (!workbook) return;
    setSelectedSheet(sheetName);
    const sheetObj = workbook.sheets[sheetName];
    if (sheetObj) {
      setMapping(autoDetectColumnMapping(sheetObj.headers));
    }
  };

  const handleMappingChange = (fieldKey: ExcelFieldKey, headerName: string) => {
    setMapping((prev) => ({
      ...prev,
      [fieldKey]: headerName || undefined,
    }));
  };

  const handleCommit = () => {
    if (summary.actionable === 0) return;
    const result = onCommitImport(parsedRows, duplicateStrategy);
    setImportResult(result);
  };

  const resetUpload = () => {
    setWorkbook(null);
    setSelectedSheet('');
    setMapping({});
    setReadError(null);
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Excel İle Toplu Tedarikçi Aktarımı
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              .xlsx, .xls veya .csv dosyalarını yükleyin. Birden fazla e-posta
              adresini noktalı virgül (;) veya virgül ile ayırabilir, anket
              kriterlerini 1–5 arası puanlayabilirsiniz.
            </p>
          </div>
          <button
            type="button"
            onClick={downloadSupplierExcelTemplate}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Örnek Excel Şablonu İndir (.xlsx)</span>
          </button>
        </div>

        <div className="mt-5">
          <input
            ref={fileInputRef}
            id="excel-file-input"
            type="file"
            accept=".xlsx,.xls,.csv"
            aria-label="Excel dosyası seç"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
            }}
            className="sr-only"
          />

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) void handleFile(file);
            }}
            className={`border border-dashed rounded-xl p-8 text-center transition-colors ${
              isDragging
                ? 'border-blue-700 bg-blue-50/50'
                : 'border-slate-300 bg-slate-50/60'
            }`}
          >
            <FileSpreadsheet className="w-8 h-8 text-slate-400 mx-auto" />
            {workbook ? (
              <div className="mt-3">
                <p className="text-sm font-semibold text-slate-900">
                  Yüklü Dosya: {workbook.fileName}
                </p>
                <p className="mt-1 text-xs text-slate-500 tabular-nums">
                  {currentSheetData?.rows.length ?? 0} satır tespit edildi
                </p>
                <div className="mt-4 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                  >
                    Başka Dosya Seç
                  </button>
                  <button
                    type="button"
                    onClick={resetUpload}
                    className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
                  >
                    Temizle
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-3">
                <p className="text-sm font-medium text-slate-800">
                  Excel dosyanızı buraya sürükleyin veya bilgisayarınızdan seçin
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  Zorunlu sütunlar: Firma Unvanı, Vergi No (10-11 hane).
                  Sınıflandırma: Kritik, Alternatifi Sınırlı, Onaylı veya Aday.
                </p>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Dosya Seç (.xlsx / .xls / .csv)</span>
                </button>
              </div>
            )}
          </div>

          {readError && (
            <div
              role="alert"
              className="mt-4 flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-xs font-medium text-red-700"
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{readError}</span>
            </div>
          )}
        </div>
      </section>

      {workbook && currentSheetData && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Sütun Eşleştirme ve Çakışma Kuralı
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                Başlıklar otomatik eşleştirildi; gerekirse alan karşılıklarını
                düzenleyin.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {workbook.sheetNames.length > 1 && (
                <div className="flex items-center gap-2">
                  <label
                    htmlFor="excel-sheet-select"
                    className="text-xs font-medium text-slate-600"
                  >
                    Sayfa:
                  </label>
                  <select
                    id="excel-sheet-select"
                    value={selectedSheet}
                    onChange={(e) => handleSheetChange(e.target.value)}
                    className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800"
                  >
                    {workbook.sheetNames.map((name) => (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex items-center gap-2">
                <label
                  htmlFor="duplicate-strategy-select"
                  className="text-xs font-medium text-slate-600"
                >
                  Aynı Vergi No varsa:
                </label>
                <select
                  id="duplicate-strategy-select"
                  value={duplicateStrategy}
                  onChange={(e) =>
                    setDuplicateStrategy(e.target.value as DuplicateStrategy)
                  }
                  className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800"
                >
                  <option value="update">Mevcut tedarikçiyi güncelle</option>
                  <option value="skip">Mükerrer satırı atla</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {EXCEL_FIELD_DEFINITIONS.map((field) => (
              <div key={field.key}>
                <label
                  htmlFor={`map-${field.key}`}
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  {field.label}
                  {field.required && (
                    <span className="text-red-600 ml-0.5">*</span>
                  )}
                </label>
                <select
                  id={`map-${field.key}`}
                  value={mapping[field.key] ?? ''}
                  onChange={(e) => handleMappingChange(field.key, e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                >
                  <option value="">— Eşleştirilmedi —</option>
                  {currentSheetData.headers.map((header) => (
                    <option key={header} value={header}>
                      {header}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </section>
      )}

      {workbook && parsedRows.length > 0 && (
        <section className="bg-white border border-slate-200 rounded-xl">
          <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Aktarım Önizleme ve Doğrulama
              </h3>
              <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-600 tabular-nums">
                <span>Toplam: {summary.total}</span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-emerald-700">
                  Yeni Kayıt: {summary.validNew}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-blue-700">
                  Güncellenecek: {summary.validUpdate}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-slate-500">
                  Atlanan: {summary.skipped}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-red-700">
                  Hatalı: {summary.invalid}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {importResult ? (
                <button
                  type="button"
                  onClick={onGoToList}
                  className="px-4 py-2 text-xs font-medium text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 transition-colors whitespace-nowrap"
                >
                  Tedarikçi Listesine Git
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleCommit}
                  disabled={summary.actionable === 0}
                  className="px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 disabled:opacity-50 transition-colors whitespace-nowrap"
                >
                  Geçerli Satırları İçe Aktar ({summary.actionable})
                </button>
              )}
            </div>
          </div>

          {importResult && (
            <div
              role="status"
              className="m-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-900"
            >
              <div className="flex items-center gap-2 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>
                  Aktarım tamamlandı: {importResult.added} yeni tedarikçi eklendi,{' '}
                  {importResult.updated} tedarikçi güncellendi,{' '}
                  {importResult.skipped} satır atlandı.
                </span>
              </div>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-2.5 pl-4 pr-3">Satır</th>
                  <th className="py-2.5 px-3">Durum</th>
                  <th className="py-2.5 px-3">Firma Unvanı</th>
                  <th className="py-2.5 px-3">Vergi No</th>
                  <th className="py-2.5 px-3">Sınıflandırma</th>
                  <th className="py-2.5 px-3">E-posta Sayısı</th>
                  <th className="py-2.5 pl-3 pr-4">Doğrulama Notu</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {parsedRows.map((row) => {
                  const statusLabel =
                    row.status === 'valid_new'
                      ? 'Yeni Kayıt'
                      : row.status === 'valid_update'
                      ? 'Güncelleme'
                      : row.status === 'duplicate_skipped'
                      ? 'Atlandı'
                      : 'Hatalı';
                  const statusClass =
                    row.status === 'valid_new'
                      ? 'text-emerald-700 font-semibold'
                      : row.status === 'valid_update'
                      ? 'text-blue-700 font-semibold'
                      : row.status === 'duplicate_skipped'
                      ? 'text-slate-500 font-medium'
                      : 'text-red-700 font-semibold';

                  return (
                    <tr key={row.rowIndex} className="hover:bg-slate-50">
                      <td className="py-2.5 pl-4 pr-3 font-mono tabular-nums text-slate-500">
                        #{row.rowIndex}
                      </td>
                      <td className={`py-2.5 px-3 whitespace-nowrap ${statusClass}`}>
                        {statusLabel}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        {row.normalized?.name ||
                          (mapping.name ? String(row.raw[mapping.name] ?? '') : '-')}
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-600">
                        {row.normalized?.taxNumber ||
                          (mapping.taxNumber
                            ? String(row.raw[mapping.taxNumber] ?? '')
                            : '-')}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {row.normalized?.classification || '-'}
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-600">
                        {row.normalized ? row.normalized.emails.length : 0}
                      </td>
                      <td className="py-2.5 pl-3 pr-4 text-slate-600">
                        {row.errors.length > 0 ? (
                          <span className="text-red-700">{row.errors.join(' ')}</span>
                        ) : row.status === 'duplicate_skipped' ? (
                          'Aynı Vergi No sistemde mevcut olduğu için atlandı.'
                        ) : row.status === 'valid_update' ? (
                          'Mevcut tedarikçi kartı güncellenecek.'
                        ) : (
                          'Aktarıma hazır.'
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
