import { useMemo } from 'react';
import type { PerformanceTier, SupplierWithScore } from '../types/supplier';
import {
  CLASSIFICATION_TEXT_COLOR,
  EVALUATION_SCALE_TABLE,
  SURVEY_CRITERIA,
  computeAnalyticsSummary,
} from '../utils/supplierLogic';

interface AnalyticsViewProps {
  suppliers: SupplierWithScore[];
  onSelectSupplier: (supplierId: string) => void;
  onScoreSupplier: (supplierId: string) => void;
}

const TIER_BAR_COLOR: Record<PerformanceTier, string> = {
  A: 'bg-emerald-600',
  B: 'bg-blue-600',
  C: 'bg-amber-500',
  D: 'bg-red-600',
};

export function AnalyticsView({
  suppliers,
  onSelectSupplier,
  onScoreSupplier,
}: AnalyticsViewProps) {
  const summary = useMemo(() => computeAnalyticsSummary(suppliers), [suppliers]);

  if (suppliers.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
        <p className="text-sm font-medium text-slate-900">
          Analiz için tedarikçi verisi bulunmuyor
        </p>
        <p className="mt-1 text-sm text-slate-500">
          Tedarikçi eklendikçe sınıf dağılımları ve kriter ortalamaları burada
          görünür.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-baseline justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Anket Derecesi Dağılımı (Maks. 25 Puan)
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Toplam {summary.totalSuppliers} tedarikçinin A–D değerlendirme özeti
              </p>
            </div>
            <span className="font-mono text-sm font-semibold tabular-nums text-slate-900">
              Ort. {summary.averageTotalScore.toFixed(1)} / 25
            </span>
          </div>

          <div className="mt-5 space-y-4">
            {EVALUATION_SCALE_TABLE.map((row) => {
              const count = summary.tierCounts[row.tier];
              const pct =
                summary.totalSuppliers > 0
                  ? Math.round((count / summary.totalSuppliers) * 100)
                  : 0;
              return (
                <div key={row.tier}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div>
                      <span className={`font-semibold ${row.textColor}`}>
                        ({row.tier}) {row.rangeLabel} · {row.resultLabel}
                      </span>
                      <span className="ml-2 text-slate-400">
                        {row.actionLabel}
                      </span>
                    </div>
                    <div className="font-mono tabular-nums text-slate-700">
                      <span className="font-semibold text-slate-900">{count}</span>{' '}
                      firma · %{pct}
                    </div>
                  </div>
                  <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${TIER_BAR_COLOR[row.tier]} rounded-full`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="pb-4 border-b border-slate-200">
            <h2 className="text-base font-semibold text-slate-900">
              5 Anket Kriteri Portföy Ortalaması (1–5)
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Tüm tedarikçilerin her anket sorusundaki ortalama performansı
            </p>
          </div>

          <div className="mt-5 space-y-4">
            {SURVEY_CRITERIA.map((criterion) => {
              const avg = summary.criterionAverages[criterion.key];
              const pct = Math.min(100, Math.max(0, (avg / 5) * 100));
              return (
                <div key={criterion.key}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-slate-900">
                      {criterion.order}. {criterion.label}
                    </span>
                    <span className="font-mono font-semibold tabular-nums text-slate-900">
                      {avg.toFixed(1)} / 5
                    </span>
                  </div>
                  <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-700 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Category Averages */}
      <section className="bg-white border border-slate-200 rounded-xl">
        <div className="p-5 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">
            Kategori Bazlı Performans Özeti
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Satın alma kategorilerine göre tedarikçi yoğunluğu ve 25 puanlık ortalama
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                <th className="py-2.5 pl-5 pr-3">Kategori</th>
                <th className="py-2.5 px-3 text-right">Firma Sayısı</th>
                <th className="py-2.5 px-3 text-right">Ortalama Puan (25)</th>
                <th className="py-2.5 pl-3 pr-5">En Yüksek Puanlı Tedarikçi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {summary.categoryStats.map((cat) => (
                <tr key={cat.category} className="hover:bg-slate-50">
                  <td className="py-3 pl-5 pr-3 font-medium text-slate-900">
                    {cat.category}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-xs tabular-nums text-slate-700">
                    {cat.count}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sm font-semibold tabular-nums text-slate-900">
                    {cat.averageScore.toFixed(1)} / 25
                  </td>
                  <td className="py-3 pl-3 pr-5 text-xs text-slate-600">
                    {cat.topSupplierName}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Top Performers & Action Required */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <h2 className="text-base font-semibold text-slate-900 pb-3 border-b border-slate-200">
            En Yüksek Puanlı Tedarikçiler (A / B)
          </h2>
          {summary.topPerformers.length === 0 ? (
            <p className="mt-4 text-xs text-slate-500">
              A veya B grubunda tedarikçi bulunmuyor.
            </p>
          ) : (
            <ul className="divide-y divide-slate-200 mt-1">
              {summary.topPerformers.map((s) => (
                <li
                  key={s.id}
                  className="py-3 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => onSelectSupplier(s.id)}
                      className="text-sm font-medium text-slate-900 hover:text-blue-700 truncate block text-left"
                    >
                      {s.name}
                    </button>
                    <span className="text-xs text-slate-500">
                      <span className={CLASSIFICATION_TEXT_COLOR[s.classification]}>
                        {s.classification}
                      </span>{' '}
                      · {s.category} · {s.city}
                    </span>
                  </div>
                  <div className="text-right shrink-0 font-mono tabular-nums">
                    <span className="text-sm font-semibold text-slate-900">
                      {s.totalScore}/25
                    </span>
                    <span className={`ml-2 text-xs font-semibold ${s.outcome.textColor}`}>
                      ({s.tier})
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <h2 className="text-base font-semibold text-slate-900 pb-3 border-b border-slate-200">
            DİF / Askıya Alma Takip Listesi (≤ 15 Puan)
          </h2>
          {summary.actionRequiredList.length === 0 ? (
            <p className="mt-4 text-xs text-slate-500">
              15 puan ve altında tedarikçi bulunmuyor.
            </p>
          ) : (
            <ul className="divide-y divide-slate-200 mt-1">
              {summary.actionRequiredList.map((s) => (
                <li
                  key={s.id}
                  className="py-3 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => onSelectSupplier(s.id)}
                      className="text-sm font-medium text-slate-900 hover:text-blue-700 truncate block text-left"
                    >
                      {s.name}
                    </button>
                    <span className="text-xs text-slate-500">
                      {s.classification} · Aksiyon: {s.outcome.actionLabel}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className={`font-mono text-sm font-semibold tabular-nums ${s.outcome.textColor}`}>
                      {s.totalScore}/25 ({s.tier})
                    </span>
                    <button
                      type="button"
                      onClick={() => onScoreSupplier(s.id)}
                      className="px-2.5 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-md"
                    >
                      Yeniden Puanla
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
