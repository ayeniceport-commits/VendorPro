import { useEffect, useState } from 'react';
import { ClipboardCheck, Pencil, Trash2, TrendingUp, X } from 'lucide-react';
import type { SupplierWithScore } from '../types/supplier';
import {
  CLASSIFICATION_TEXT_COLOR,
  SURVEY_CRITERIA,
  computeScoreProgression,
  formatShortTrDate,
} from '../utils/supplierLogic';
import { ScoreProgressionChart } from './ScoreProgressionChart';

interface SupplierDetailDrawerProps {
  supplier: SupplierWithScore | null;
  onClose: () => void;
  onEdit: (supplier: SupplierWithScore) => void;
  onDelete: (supplierId: string) => void;
  onScore: (supplierId: string) => void;
  onOpenHistory: (supplierId: string) => void;
}

export function SupplierDetailDrawer({
  supplier,
  onClose,
  onEdit,
  onDelete,
  onScore,
  onOpenHistory,
}: SupplierDetailDrawerProps) {
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setConfirmDelete(false);
  }, [supplier?.id]);

  if (!supplier) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-supplier-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/35"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-xl bg-white h-full overflow-y-auto border-l border-slate-200 flex flex-col justify-between">
        <div>
          <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="text-xs font-mono text-slate-500 tabular-nums flex items-center gap-1.5">
                <span>{supplier.code}</span>
                <span aria-hidden="true">·</span>
                <span className={`font-sans font-semibold ${CLASSIFICATION_TEXT_COLOR[supplier.classification]}`}>
                  {supplier.classification}
                </span>
              </div>
              <h2
                id="drawer-supplier-title"
                className="mt-0.5 text-lg font-semibold text-slate-900"
              >
                {supplier.name}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Tedarikçi detay panelini kapat"
              className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-900"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Performance Score Summary */}
            <div className="flex items-center justify-between gap-4 pb-5 border-b border-slate-200">
              <div>
                <span className="block text-xs text-slate-500">
                  Anket Performans Puanı
                </span>
                <div className="mt-1 flex items-baseline gap-2.5">
                  <span className="font-mono text-3xl font-bold tabular-nums text-slate-900">
                    {supplier.totalScore} / 25
                  </span>
                  <span className={`text-sm font-semibold ${supplier.outcome.textColor}`}>
                    ({supplier.outcome.tier}) {supplier.outcome.resultLabel}
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-600">
                  Aksiyon: <span className="font-medium text-slate-900">{supplier.outcome.actionLabel}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => onScore(supplier.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 whitespace-nowrap shrink-0"
              >
                <ClipboardCheck className="w-3.5 h-3.5" />
                <span>Anket ile Puanla</span>
              </button>
            </div>

            {/* Company Information */}
            <section>
              <h3 className="text-xs font-semibold text-slate-900 mb-3">
                Cari, İletişim ve Adres Bilgileri
              </h3>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                <div>
                  <dt className="text-slate-500">Vergi No / TCKN</dt>
                  <dd className="mt-0.5 font-mono tabular-nums font-medium text-slate-900">
                    {supplier.taxNumber}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Vergi Dairesi</dt>
                  <dd className="mt-0.5 font-medium text-slate-900">
                    {supplier.taxOffice}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Kategori</dt>
                  <dd className="mt-0.5 font-medium text-slate-900">
                    {supplier.category}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Sınıflandırma</dt>
                  <dd className={`mt-0.5 font-semibold ${CLASSIFICATION_TEXT_COLOR[supplier.classification]}`}>
                    {supplier.classification}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Yetkili Kişi</dt>
                  <dd className="mt-0.5 font-medium text-slate-900">
                    {supplier.contactPerson}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Yetkili Telefon</dt>
                  <dd className="mt-0.5 font-mono tabular-nums font-medium text-slate-900">
                    {supplier.phone || '-'}
                  </dd>
                </div>
                <div className="col-span-2">
                  <dt className="text-slate-500">E-posta Adresleri</dt>
                  <dd className="mt-0.5 font-medium text-slate-900 space-y-0.5">
                    {supplier.emails.length > 0 ? (
                      supplier.emails.map((email) => (
                        <div key={email} className="break-all">
                          {email}
                        </div>
                      ))
                    ) : (
                      <span>-</span>
                    )}
                  </dd>
                </div>
                <div className="col-span-2">
                  <dt className="text-slate-500">Şehir &amp; Adres</dt>
                  <dd className="mt-0.5 font-medium text-slate-900">
                    {supplier.city}
                    {supplier.address && supplier.address !== '-'
                      ? ` · ${supplier.address}`
                      : ''}
                  </dd>
                </div>
              </dl>
              {supplier.notes && (
                <div className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600">
                  <span className="font-medium text-slate-700">Not: </span>
                  {supplier.notes}
                </div>
              )}
            </section>

            {/* 5 Criteria Breakdown (1-5) */}
            <section className="pt-4 border-t border-slate-200">
              <h3 className="text-xs font-semibold text-slate-900 mb-3">
                5 Kriterli Anket Puan Dağılımı
              </h3>
              <div className="space-y-3">
                {SURVEY_CRITERIA.map((criterion) => {
                  const val = supplier.scores[criterion.key];
                  return (
                    <div key={criterion.key}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-slate-700">
                          {criterion.order}. {criterion.label}
                        </span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          {val} / 5
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-700 rounded-full"
                          style={{ width: `${(val / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Evaluation History */}
            {(() => {
              const progression = computeScoreProgression(supplier.evaluations);
              const descending = [...progression.chronological].reverse();
              return (
                <section className="pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <h3 className="text-xs font-semibold text-slate-900">
                      Değerlendirme Geçmişi ({progression.count})
                    </h3>
                    <button
                      type="button"
                      onClick={() => onOpenHistory(supplier.id)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md whitespace-nowrap"
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>GEÇMİŞ PERFORMANS</span>
                    </button>
                  </div>

                  <div className="mb-3">
                    <ScoreProgressionChart evaluations={progression.chronological} compact />
                  </div>

                  {descending.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      Henüz dönemsel değerlendirme kaydı yok.
                    </p>
                  ) : (
                    <ul className="divide-y divide-slate-200">
                      {descending.map((ev) => (
                        <li key={ev.id} className="py-3">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-semibold text-slate-800">
                              {ev.period} ·{' '}
                              <span className="font-mono font-normal text-slate-500">
                                {formatShortTrDate(ev.date)}
                              </span>
                            </span>
                            <span className="font-mono font-semibold tabular-nums text-slate-900">
                              {ev.totalScore}/25 ({ev.tier}) · {ev.resultLabel}
                            </span>
                          </div>
                          <p className="mt-1 text-xs text-slate-600">{ev.notes}</p>
                          <p className="mt-0.5 text-xs text-slate-400">
                            {ev.evaluator} · Aksiyon: {ev.actionLabel}
                          </p>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              );
            })()}
          </div>
        </div>

        <div className="sticky bottom-0 bg-white border-t border-slate-200 px-6 py-4 flex items-center justify-between gap-3">
          {confirmDelete ? (
            <div className="flex items-center gap-2 w-full justify-between">
              <span className="text-xs font-medium text-red-700">
                Bu tedarikçi silinsin mi?
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200"
                >
                  Vazgeç
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onDelete(supplier.id);
                    setConfirmDelete(false);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-lg hover:bg-red-700"
                >
                  Evet, Sil
                </button>
              </div>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-700 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sil</span>
              </button>
              <button
                type="button"
                onClick={() => onEdit(supplier)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>Bilgileri Güncelle</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
