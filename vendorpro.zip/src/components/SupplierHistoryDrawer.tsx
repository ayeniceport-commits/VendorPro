import { useEffect, useState } from 'react';
import { ClipboardCheck, TrendingDown, TrendingUp, Minus, X } from 'lucide-react';
import type { SupplierWithScore } from '../types/supplier';
import {
  CLASSIFICATION_TEXT_COLOR,
  SURVEY_CRITERIA,
  computeScoreProgression,
  formatShortTrDate,
  getEvaluationOutcome,
} from '../utils/supplierLogic';
import { ScoreProgressionChart } from './ScoreProgressionChart';

interface SupplierHistoryDrawerProps {
  supplier: SupplierWithScore | null;
  suppliers: SupplierWithScore[];
  onSelectSupplierId: (supplierId: string) => void;
  onClose: () => void;
  onScoreSupplier: (supplierId: string) => void;
}

export function SupplierHistoryDrawer({
  supplier,
  suppliers,
  onSelectSupplierId,
  onClose,
  onScoreSupplier,
}: SupplierHistoryDrawerProps) {
  const [selectedEvalId, setSelectedEvalId] = useState<string | null>(null);

  useEffect(() => {
    setSelectedEvalId(null);
  }, [supplier?.id]);

  if (!supplier) return null;

  const progression = computeScoreProgression(supplier.evaluations);
  const reverseChronological = [...progression.chronological].reverse();

  const formatDelta = (delta: number | null) => {
    if (delta === null) return '—';
    if (delta > 0) return `+${delta} puan`;
    if (delta < 0) return `${delta} puan`;
    return 'Değişim yok (0)';
  };

  const deltaColor = (delta: number | null) => {
    if (delta === null || delta === 0) return 'text-slate-600';
    return delta > 0 ? 'text-emerald-700' : 'text-red-700';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="history-drawer-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-3xl bg-white h-full overflow-y-auto border-l border-slate-200 flex flex-col justify-between">
        <div>
          {/* Sticky Header */}
          <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-start justify-between gap-4 z-10">
            <div className="min-w-0 flex-1">
              <div className="text-xs font-mono text-slate-500 tabular-nums flex items-center gap-1.5">
                <span>{supplier.code}</span>
                <span aria-hidden="true">·</span>
                <span className={`font-sans font-semibold ${CLASSIFICATION_TEXT_COLOR[supplier.classification]}`}>
                  {supplier.classification}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-sans">{supplier.category}</span>
              </div>
              <h2
                id="history-drawer-title"
                className="mt-0.5 text-base font-semibold text-slate-900 truncate"
              >
                Geçmiş Performans &amp; Puan Gelişimi — {supplier.name}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Geçmiş performans panelini kapat"
              className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-900 shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Supplier Switcher */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
              <div className="flex-1 min-w-0">
                <label
                  htmlFor="history-supplier-select"
                  className="block text-xs font-medium text-slate-500 mb-1"
                >
                  Tedarikçi Seçimi
                </label>
                <select
                  id="history-supplier-select"
                  value={supplier.id}
                  onChange={(e) => onSelectSupplierId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} — {s.name} ({s.evaluations.length} dönem · Güncel: {s.totalScore}/25)
                    </option>
                  ))}
                </select>
              </div>
              <div className="shrink-0 sm:pt-5">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onScoreSupplier(supplier.id);
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 whitespace-nowrap"
                >
                  <ClipboardCheck className="w-3.5 h-3.5" />
                  <span>Yeni Dönem Puanla</span>
                </button>
              </div>
            </div>

            {/* 4 Progression Summary Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <span className="block text-xs text-slate-500">Son Puan</span>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="font-mono text-xl font-bold tabular-nums text-slate-900">
                    {progression.latest ? `${progression.latest.totalScore} / 25` : `${supplier.totalScore} / 25`}
                  </span>
                  <span className={`font-mono text-xs font-semibold ${supplier.outcome.textColor}`}>
                    ({supplier.tier})
                  </span>
                </div>
                <span className="block mt-0.5 text-xs text-slate-500">
                  {progression.latest ? `${progression.latest.period} · ${formatShortTrDate(progression.latest.date)}` : 'Kayıt yok'}
                </span>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <span className="block text-xs text-slate-500">Önceki Döneme Göre</span>
                <div className={`mt-1 flex items-center gap-1 font-mono text-lg font-bold tabular-nums ${deltaColor(progression.deltaFromPrevious)}`}>
                  {progression.deltaFromPrevious !== null && progression.deltaFromPrevious > 0 && (
                    <TrendingUp className="w-4 h-4 shrink-0" />
                  )}
                  {progression.deltaFromPrevious !== null && progression.deltaFromPrevious < 0 && (
                    <TrendingDown className="w-4 h-4 shrink-0" />
                  )}
                  {progression.deltaFromPrevious === 0 && <Minus className="w-4 h-4 shrink-0" />}
                  <span>{formatDelta(progression.deltaFromPrevious)}</span>
                </div>
                <span className="block mt-0.5 text-xs text-slate-500">
                  {progression.previous
                    ? `${progression.previous.period}: ${progression.previous.totalScore}/25`
                    : 'Tek dönem kaydı'}
                </span>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <span className="block text-xs text-slate-500">İlk Kayda Göre Gelişim</span>
                <div className={`mt-1 font-mono text-lg font-bold tabular-nums ${deltaColor(progression.deltaFromFirst)}`}>
                  {formatDelta(progression.deltaFromFirst)}
                </div>
                <span className="block mt-0.5 text-xs text-slate-500">
                  {progression.count >= 2
                    ? `${progression.chronological[0].period} → ${progression.latest?.period}`
                    : `${progression.count} değerlendirme`}
                </span>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <span className="block text-xs text-slate-500">Dönem Ort. / Aralık</span>
                <div className="mt-1 font-mono text-lg font-bold tabular-nums text-slate-900">
                  {progression.count > 0 ? `${progression.averageScore.toFixed(1)} / 25` : '—'}
                </div>
                <span className="block mt-0.5 text-xs text-slate-500 font-mono tabular-nums">
                  {progression.count > 0
                    ? `Min ${progression.minScore} · Maks ${progression.maxScore} (${progression.count} dönem)`
                    : 'Değerlendirme bekleniyor'}
                </span>
              </div>
            </div>

            {/* Chart Card */}
            <section className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Tarih Bazlı Puan Gelişim Grafiği (Maks. 25)
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Kesikli çizgiler değerlendirme derecelerini gösterir: 21 (A) · 16 (B) · 11 (C).
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-600">
                  <span className="inline-flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-700" /> A (21–25)
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-blue-700" /> B (16–20)
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-700" /> C (11–15)
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-700" /> D (≤10)
                  </span>
                </div>
              </div>
              <div className="mt-4">
                <ScoreProgressionChart
                  evaluations={progression.chronological}
                  selectedEvalId={selectedEvalId}
                  onSelectEvaluation={(id) =>
                    setSelectedEvalId((prev) => (prev === id ? null : id))
                  }
                />
              </div>
            </section>

            {/* Detailed Period + Criterion History Table */}
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Dönem ve Kriter Bazlı Gelişim Kayıtları ({progression.count})
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Her değerlendirme döneminin 5 anket sorusu puanı ve bir önceki döneme göre değişimi
                  </p>
                </div>
              </div>

              {reverseChronological.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  Bu tedarikçi için henüz dönemsel değerlendirme kaydı yok.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500">
                        <th className="py-2.5 pl-4 pr-2 font-medium whitespace-nowrap">Dönem &amp; Tarih</th>
                        {SURVEY_CRITERIA.map((c) => (
                          <th key={c.key} className="py-2.5 px-2 font-medium text-center whitespace-nowrap" title={c.label}>
                            {c.order}. {c.label.split(' ')[0]}
                          </th>
                        ))}
                        <th className="py-2.5 px-2.5 font-medium text-right whitespace-nowrap">Toplam</th>
                        <th className="py-2.5 px-2.5 font-medium text-right whitespace-nowrap">Fark</th>
                        <th className="py-2.5 pl-2.5 pr-4 font-medium">Değerlendiren &amp; Not</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {reverseChronological.map((ev) => {
                        const chronoIdx = progression.chronological.findIndex((item) => item.id === ev.id);
                        const prevEv = chronoIdx > 0 ? progression.chronological[chronoIdx - 1] : null;
                        const stepDelta = prevEv ? ev.totalScore - prevEv.totalScore : null;
                        const outcome = getEvaluationOutcome(ev.totalScore);
                        const isHighlighted = selectedEvalId === ev.id;

                        return (
                          <tr
                            key={ev.id}
                            onClick={() =>
                              setSelectedEvalId((prev) => (prev === ev.id ? null : ev.id))
                            }
                            className={`cursor-pointer ${
                              isHighlighted ? 'bg-blue-50/70' : 'hover:bg-slate-50/80'
                            }`}
                          >
                            <td className="py-3 pl-4 pr-2 whitespace-nowrap align-top">
                              <div className="font-semibold text-slate-900">{ev.period}</div>
                              <div className="font-mono text-slate-500 tabular-nums">
                                {formatShortTrDate(ev.date)}
                              </div>
                            </td>
                            {SURVEY_CRITERIA.map((c) => (
                              <td
                                key={c.key}
                                className="py-3 px-2 text-center font-mono tabular-nums text-slate-700 align-top"
                              >
                                {ev.scores[c.key]}/5
                              </td>
                            ))}
                            <td className="py-3 px-2.5 text-right whitespace-nowrap align-top">
                              <div className="font-mono font-bold tabular-nums text-slate-900">
                                {ev.totalScore} / 25
                              </div>
                              <div className={`font-semibold ${outcome.textColor}`}>
                                ({ev.tier}) {ev.resultLabel}
                              </div>
                            </td>
                            <td className="py-3 px-2.5 text-right font-mono font-semibold tabular-nums whitespace-nowrap align-top">
                              {stepDelta === null ? (
                                <span className="text-slate-400">İlk</span>
                              ) : stepDelta > 0 ? (
                                <span className="text-emerald-700">+{stepDelta}</span>
                              ) : stepDelta < 0 ? (
                                <span className="text-red-700">{stepDelta}</span>
                              ) : (
                                <span className="text-slate-500">0</span>
                              )}
                            </td>
                            <td className="py-3 pl-2.5 pr-4 max-w-[230px] align-top">
                              <div className="font-medium text-slate-800">{ev.evaluator}</div>
                              <div className="mt-0.5 text-slate-500 leading-relaxed">{ev.notes}</div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </div>
        </div>

        <div className="sticky bottom-0 bg-white border-t border-slate-200 px-6 py-4 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
}
