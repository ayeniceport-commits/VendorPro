import { useMemo, useState } from 'react';
import {
  ArrowDownUp,
  ChevronRight,
  Download,
  FileSpreadsheet,
  Pencil,
  Search,
  SlidersHorizontal,
  Tag,
  TrendingUp,
} from 'lucide-react';
import type {
  SortDirection,
  SortField,
  SupplierWithScore,
} from '../types/supplier';
import { exportSuppliersToExcel } from '../utils/excelService';
import {
  CLASSIFICATION_OPTIONS,
  CLASSIFICATION_TEXT_COLOR,
  computeScoreProgression,
  filterAndSortSuppliers,
} from '../utils/supplierLogic';

interface SupplierListViewProps {
  suppliers: SupplierWithScore[];
  categories: string[];
  onSelectSupplier: (supplierId: string) => void;
  onEditSupplier: (supplierId: string) => void;
  onScoreSupplier: (supplierId: string) => void;
  onOpenHistory: (supplierId: string) => void;
  onOpenCategoryManager: () => void;
  onGoToImport: () => void;
  onOpenNewSupplier: () => void;
}

export function SupplierListView({
  suppliers,
  categories: configuredCategories,
  onSelectSupplier,
  onEditSupplier,
  onScoreSupplier,
  onOpenHistory,
  onOpenCategoryManager,
  onGoToImport,
  onOpenNewSupplier,
}: SupplierListViewProps) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('ALL');
  const [classification, setClassification] = useState('ALL');
  const [tier, setTier] = useState('ALL');
  const [sortField, setSortField] = useState<SortField>('totalScore');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const categories = useMemo(() => {
    const set = new Set([...configuredCategories, ...suppliers.map((s) => s.category)]);
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'tr'));
  }, [configuredCategories, suppliers]);

  const filteredSuppliers = useMemo(
    () =>
      filterAndSortSuppliers(suppliers, {
        search,
        category,
        classification,
        tier,
        sortField,
        sortDirection,
      }),
    [suppliers, search, category, classification, tier, sortField, sortDirection]
  );

  const kpis = useMemo(() => {
    const total = suppliers.length;
    const kritikCount = suppliers.filter((s) => s.classification === 'Kritik').length;
    const limitedCount = suppliers.filter(
      (s) => s.classification === 'Alternatifi Sınırlı'
    ).length;
    const onayliCount = suppliers.filter((s) => s.classification === 'Onaylı').length;
    const adayCount = suppliers.filter((s) => s.classification === 'Aday').length;
    const avg =
      total > 0
        ? Math.round(
            (suppliers.reduce((sum, s) => sum + s.totalScore, 0) / total) * 10
          ) / 10
        : 0;
    const excellentCount = suppliers.filter((s) => s.tier === 'A').length;
    const actionCount = suppliers.filter((s) => s.tier === 'C' || s.tier === 'D').length;
    return {
      total,
      kritikCount,
      limitedCount,
      onayliCount,
      adayCount,
      avg,
      excellentCount,
      actionCount,
    };
  }, [suppliers]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection(field === 'totalScore' ? 'desc' : 'asc');
    }
  };

  const resetFilters = () => {
    setSearch('');
    setCategory('ALL');
    setClassification('ALL');
    setTier('ALL');
  };

  const hasActiveFilter =
    search.trim() !== '' ||
    category !== 'ALL' ||
    classification !== 'ALL' ||
    tier !== 'ALL';

  return (
    <div className="space-y-6">
      {/* KPI Summary Strip */}
      <section
        aria-label="Tedarikçi özet göstergeleri"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <span className="block text-xs font-medium text-slate-500">
            Toplam Tedarikçi
          </span>
          <div className="mt-1.5 flex items-baseline gap-2 flex-wrap">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-900">
              {kpis.total}
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              {kpis.kritikCount} kritik · {kpis.limitedCount} alt. sınırlı · {kpis.onayliCount} onaylı · {kpis.adayCount} aday
            </span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <span className="block text-xs font-medium text-slate-500">
            Ortalama Anket Puanı
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-slate-900">
              {kpis.avg.toFixed(1)}
            </span>
            <span className="text-xs text-slate-500">/ 25 puan</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <span className="block text-xs font-medium text-slate-500">
            (A) Mükemmel · 21–25
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-emerald-700">
              {kpis.excellentCount}
            </span>
            <span className="text-xs text-slate-500">Yıllık gözden geçirme</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <span className="block text-xs font-medium text-slate-500">
            (C/D) Aksiyon Gereken · ≤15
          </span>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold tabular-nums text-amber-700">
              {kpis.actionCount}
            </span>
            <span className="text-xs text-slate-500">DİF veya askıya alma</span>
          </div>
        </div>
      </section>

      {/* Toolbar & Filters */}
      <section className="bg-white border border-slate-200 rounded-xl">
        <div className="p-4 border-b border-slate-200 space-y-3">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex flex-1 flex-wrap items-center gap-2.5">
              <div className="relative flex-1 min-w-[220px] max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <label htmlFor="supplier-search" className="sr-only">
                  Tedarikçi ara
                </label>
                <input
                  id="supplier-search"
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Unvan, kod, VKN, adres veya e-posta ara..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              </div>

              <div>
                <label htmlFor="filter-category" className="sr-only">
                  Kategori filtresi
                </label>
                <select
                  id="filter-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                >
                  <option value="ALL">Tüm Kategoriler</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="filter-classification" className="sr-only">
                  Sınıflandırma filtresi
                </label>
                <select
                  id="filter-classification"
                  value={classification}
                  onChange={(e) => setClassification(e.target.value)}
                  className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                >
                  <option value="ALL">Tüm Sınıflandırmalar</option>
                  {CLASSIFICATION_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={onOpenCategoryManager}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
              >
                <Tag className="w-3.5 h-3.5 text-slate-500" />
                <span>Kategorileri Yönet</span>
              </button>
              <button
                type="button"
                onClick={onGoToImport}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-slate-500" />
                <span>Excel&apos;den Aktar</span>
              </button>
              <button
                type="button"
                onClick={() => exportSuppliersToExcel(filteredSuppliers)}
                disabled={filteredSuppliers.length === 0}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Excel&apos;e Aktar</span>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-xs font-medium text-slate-500">
                Anket Derecesi:
              </span>
              <div
                role="group"
                aria-label="Anket derecesi filtresi"
                className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg"
              >
                {(
                  [
                    { id: 'ALL', label: 'Tümü' },
                    { id: 'A', label: 'A (21–25)' },
                    { id: 'B', label: 'B (16–20)' },
                    { id: 'C', label: 'C (11–15)' },
                    { id: 'D', label: 'D (≤10)' },
                  ] as const
                ).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setTier(item.id)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      tier === item.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              {hasActiveFilter && (
                <button
                  type="button"
                  onClick={resetFilters}
                  className="text-xs font-medium text-blue-700 hover:text-blue-800 px-2 py-1"
                >
                  Filtreleri Temizle
                </button>
              )}
            </div>

            <span className="text-xs text-slate-500 tabular-nums">
              {filteredSuppliers.length} / {suppliers.length} tedarikçi
            </span>
          </div>
        </div>

        {/* High-Density Data Table (Vade & Durum columns removed) */}
        {suppliers.length === 0 ? (
          <div className="py-16 px-6 text-center">
            <p className="text-sm font-medium text-slate-900">
              Henüz kayıtlı tedarikçi bulunmuyor
            </p>
            <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">
              Yeni tedarikçi kartı oluşturabilir veya Excel dosyanızdaki tedarikçi
              listesini toplu olarak sisteme aktarabilirsiniz.
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={onOpenNewSupplier}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800"
              >
                İlk Tedarikçiyi Ekle
              </button>
              <button
                type="button"
                onClick={onGoToImport}
                className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                Excel İle İçe Aktar
              </button>
            </div>
          </div>
        ) : filteredSuppliers.length === 0 ? (
          <div className="py-14 px-6 text-center">
            <SlidersHorizontal className="w-5 h-5 text-slate-400 mx-auto" />
            <p className="mt-2 text-sm font-medium text-slate-900">
              Filtre kriterlerine uygun tedarikçi bulunamadı
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Arama terimini veya kategori/sınıflandırma filtrelerini temizleyerek
              tekrar deneyin.
            </p>
            {hasActiveFilter && (
              <button
                type="button"
                onClick={resetFilters}
                className="mt-4 px-3.5 py-2 text-xs font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100"
              >
                Filtreleri Temizle
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-2.5 pl-4 pr-2 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleSort('code')}
                      className="inline-flex items-center gap-1 hover:text-slate-900"
                    >
                      <span>Kod</span>
                      <ArrowDownUp className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-2.5 px-2.5">
                    <button
                      type="button"
                      onClick={() => handleSort('name')}
                      className="inline-flex items-center gap-1 hover:text-slate-900"
                    >
                      <span>Firma Unvanı &amp; Adres</span>
                      <ArrowDownUp className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleSort('category')}
                      className="inline-flex items-center gap-1 hover:text-slate-900"
                    >
                      <span>Kategori</span>
                      <ArrowDownUp className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleSort('classification')}
                      className="inline-flex items-center gap-1 hover:text-slate-900"
                    >
                      <span>Sınıflandırma</span>
                      <ArrowDownUp className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Yetkili &amp; İletişim</th>
                  <th className="py-2.5 px-2.5 text-right whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleSort('totalScore')}
                      className="inline-flex items-center gap-1 hover:text-slate-900"
                    >
                      <span>Tedarikçi Puanlama (25)</span>
                      <ArrowDownUp className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-2.5 pl-2 pr-3 text-right whitespace-nowrap">
                    İşlem
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filteredSuppliers.map((supplier) => {
                  const extraEmailCount = Math.max(0, supplier.emails.length - 1);
                  const progression = computeScoreProgression(supplier.evaluations);
                  return (
                    <tr
                      key={supplier.id}
                      className="hover:bg-slate-50/90 transition-colors"
                    >
                      <td className="py-3 pl-4 pr-2 font-mono text-xs tabular-nums text-slate-600 whitespace-nowrap align-top">
                        {supplier.code}
                      </td>
                      <td className="py-3 px-2.5 min-w-[180px] max-w-[230px] align-top">
                        <button
                          type="button"
                          onClick={() => onSelectSupplier(supplier.id)}
                          className="text-left font-medium text-slate-900 hover:text-blue-700 transition-colors block"
                        >
                          {supplier.name}
                        </button>
                        <div className="mt-0.5 text-xs text-slate-500 flex items-center gap-1.5 flex-wrap">
                          <span className="font-mono tabular-nums">
                            VKN {supplier.taxNumber}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{supplier.city}</span>
                        </div>
                        {supplier.address && supplier.address !== '-' && (
                          <div className="mt-0.5 text-xs text-slate-400 truncate">
                            {supplier.address}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-2.5 text-xs text-slate-700 min-w-[96px] max-w-[132px] align-top">
                        {supplier.category}
                      </td>
                      <td className="py-3 px-2.5 whitespace-nowrap align-top">
                        <span
                          className={`text-xs font-semibold ${
                            CLASSIFICATION_TEXT_COLOR[supplier.classification]
                          }`}
                        >
                          {supplier.classification}
                        </span>
                      </td>
                      <td className="py-3 px-2.5 min-w-[160px] max-w-[195px] align-top">
                        <div className="text-xs font-medium text-slate-800 truncate">
                          {supplier.contactPerson}
                          {supplier.phone && supplier.phone !== '-' && (
                            <span className="ml-1 font-mono font-normal text-slate-500">
                              · {supplier.phone}
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5 text-xs text-slate-500 truncate">
                          {supplier.emails[0] || '-'}
                          {extraEmailCount > 0 && (
                            <span className="ml-1 font-mono text-slate-600">
                              (+{extraEmailCount})
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-2.5 text-right whitespace-nowrap align-top">
                        <div className="inline-flex items-baseline justify-end gap-1.5">
                          <span className="font-mono text-sm font-semibold tabular-nums text-slate-900">
                            {supplier.totalScore} / 25
                          </span>
                          <span
                            className={`font-mono text-xs font-semibold ${supplier.outcome.textColor}`}
                          >
                            ({supplier.tier})
                          </span>
                        </div>
                        <div className="text-xs text-slate-500">
                          {supplier.outcome.resultLabel}
                          {progression.deltaFromPrevious !== null && progression.deltaFromPrevious !== 0 && (
                            <span
                              className={`ml-1.5 font-mono font-semibold tabular-nums ${
                                progression.deltaFromPrevious > 0 ? 'text-emerald-700' : 'text-red-700'
                              }`}
                            >
                              {progression.deltaFromPrevious > 0
                                ? `+${progression.deltaFromPrevious}`
                                : progression.deltaFromPrevious}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 pl-2 pr-3 text-right whitespace-nowrap align-top">
                        <div className="inline-flex items-center gap-0.5">
                          <button
                            type="button"
                            onClick={() => onScoreSupplier(supplier.id)}
                            aria-label={`${supplier.name} anket ile puanla`}
                            className="px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-md"
                          >
                            Puanla
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenHistory(supplier.id)}
                            aria-label={`${supplier.name} geçmiş performansını gör`}
                            title="Geçmiş Performans"
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-md"
                          >
                            <TrendingUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onEditSupplier(supplier.id)}
                            aria-label={`${supplier.name} bilgilerini güncelle`}
                            title="Düzenle"
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onSelectSupplier(supplier.id)}
                            aria-label={`${supplier.name} detaylarını aç`}
                            className="p-1 text-slate-400 hover:text-slate-900 rounded-md"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="px-4 py-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <span className="tabular-nums">
            Gösterilen: {filteredSuppliers.length} / {suppliers.length} tedarikçi
          </span>
          <span>
            Ölçek (Maks. 25): (A) 21–25 Mükemmel · (B) 16–20 İyi · (C) 11–15 Gelişim
            Gerekli · (D) ≤10 Yetersiz
          </span>
        </div>
      </section>
    </div>
  );
}
