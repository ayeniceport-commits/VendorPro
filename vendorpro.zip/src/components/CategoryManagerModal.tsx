import { useState } from 'react';
import { Check, Pencil, Plus, Trash2, X } from 'lucide-react';
import type { Supplier } from '../types/supplier';

interface CategoryManagerModalProps {
  open: boolean;
  categories: string[];
  suppliers: Supplier[];
  onClose: () => void;
  onAddCategory: (name: string) => { ok: boolean; error?: string };
  onRenameCategory: (oldName: string, newName: string) => { ok: boolean; error?: string };
  onDeleteCategory: (name: string) => { ok: boolean; error?: string };
}

export function CategoryManagerModal({
  open,
  categories,
  suppliers,
  onClose,
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
}: CategoryManagerModalProps) {
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const countByCategory = new Map<string, number>();
  for (const s of suppliers) {
    countByCategory.set(s.category, (countByCategory.get(s.category) ?? 0) + 1);
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onAddCategory(newCategoryName);
    if (!res.ok) {
      setError(res.error ?? 'Kategori eklenemedi.');
      return;
    }
    setError(null);
    setNewCategoryName('');
  };

  const handleStartEdit = (cat: string) => {
    setEditingCategory(cat);
    setEditingValue(cat);
    setError(null);
  };

  const handleCommitRename = (oldName: string) => {
    const res = onRenameCategory(oldName, editingValue);
    if (!res.ok) {
      setError(res.error ?? 'Kategori güncellenemedi.');
      return;
    }
    setError(null);
    setEditingCategory(null);
    setEditingValue('');
  };

  const handleDelete = (cat: string) => {
    const res = onDeleteCategory(cat);
    if (!res.ok) {
      setError(res.error ?? 'Kategori silinemedi.');
      return;
    }
    setError(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="category-manager-title"
    >
      <div
        className="fixed inset-0 bg-slate-900/40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-lg bg-white border border-slate-200 rounded-xl max-h-[88vh] flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2
              id="category-manager-title"
              className="text-base font-semibold text-slate-900"
            >
              Tedarikçi Kategorilerini Yönet
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Yeni kategori ekleyin, mevcut kategorileri yeniden adlandırın veya kullanılmayanları kaldırın.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Kategori yönetimini kapat"
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto">
          <form onSubmit={handleAdd} className="flex items-center gap-2">
            <label htmlFor="new-category-input" className="sr-only">
              Yeni kategori adı
            </label>
            <input
              id="new-category-input"
              type="text"
              value={newCategoryName}
              onChange={(e) => {
                setNewCategoryName(e.target.value);
                setError(null);
              }}
              placeholder="Yeni kategori adı yazın (örn. Kalibrasyon & Test)..."
              className="flex-1 px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Kategori Ekle</span>
            </button>
          </form>

          {error && (
            <p role="alert" className="text-xs font-medium text-red-700">
              {error}
            </p>
          )}

          <div className="border border-slate-200 rounded-xl divide-y divide-slate-200">
            {categories.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                Tanımlı kategori bulunmuyor.
              </div>
            ) : (
              categories.map((cat) => {
                const count = countByCategory.get(cat) ?? 0;
                const isEditing = editingCategory === cat;
                return (
                  <div
                    key={cat}
                    className="px-4 py-2.5 flex items-center justify-between gap-3"
                  >
                    {isEditing ? (
                      <div className="flex-1 flex items-center gap-2">
                        <input
                          type="text"
                          aria-label={`${cat} yeni kategori adı`}
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleCommitRename(cat);
                            } else if (e.key === 'Escape') {
                              setEditingCategory(null);
                            }
                          }}
                          className="flex-1 px-2.5 py-1.5 text-sm bg-white border border-blue-700 rounded-md text-slate-900 focus:outline-none"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => handleCommitRename(cat)}
                          aria-label="Kategori adını kaydet"
                          className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-md"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCategory(null)}
                          aria-label="Düzenlemeyi iptal et"
                          className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-md"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="min-w-0">
                          <span className="text-sm font-medium text-slate-900 block truncate">
                            {cat}
                          </span>
                          <span className="text-xs font-mono tabular-nums text-slate-500">
                            {count} tedarikçi
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleStartEdit(cat)}
                            aria-label={`${cat} kategorisini düzenle`}
                            title="Yeniden adlandır"
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(cat)}
                            disabled={count > 0 || categories.length <= 1}
                            title={
                              count > 0
                                ? `Bu kategoride ${count} tedarikçi kayıtlı olduğu için silinemez`
                                : 'Kategoriyi sil'
                            }
                            aria-label={`${cat} kategorisini sil`}
                            className="p-1.5 text-slate-400 hover:text-red-700 hover:bg-red-50 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-slate-400 rounded-md"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            Tamam
          </button>
        </div>
      </div>
    </div>
  );
}
