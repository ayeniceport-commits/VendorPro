import type { Supplier } from '../types/supplier';
import { calculateTotalScore, getEvaluationOutcome } from '../utils/supplierLogic';

function makeEval(
  id: string,
  date: string,
  period: string,
  evaluator: string,
  scores: Supplier['scores'],
  notes: string
) {
  const totalScore = calculateTotalScore(scores);
  const outcome = getEvaluationOutcome(totalScore);
  return {
    id,
    date,
    period,
    evaluator,
    scores,
    totalScore,
    tier: outcome.tier,
    resultLabel: outcome.resultLabel,
    actionLabel: outcome.actionLabel,
    notes,
  };
}

export const SUPPLIER_CATEGORIES = [
  'Hammadde & Metal',
  'Ambalaj & Baskı',
  'Lojistik & Nakliye',
  'Makine & Yedek Parça',
  'Bilişim & Yazılım',
  'Kimyasal & Sarf Malzeme',
  'Enerji & Bakım Hizmetleri',
];

export const SEED_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1001',
    code: 'TDR-1001',
    name: 'Anadolu Hassas Metal San. ve Tic. A.Ş.',
    taxNumber: '1240589312',
    taxOffice: 'Gebze İhtisas V.D.',
    category: 'Hammadde & Metal',
    classification: 'Kritik',
    city: 'Kocaeli',
    address: 'GOSB İhsan Dede Cad. No:114 Gebze / Kocaeli',
    contactPerson: 'Kerem Demirtaş',
    emails: ['kerem.demirtas@anadolumetal.com.tr', 'satis@anadolumetal.com.tr'],
    phone: '+90 262 654 18 40',
    scores: { delivery: 5, quality: 5, commercial: 4, customerService: 5, ohsEmergency: 5 },
    evaluations: [
      makeEval(
        'ev-1001-4',
        '2026-10-18',
        '2026 Q3',
        'Selin Aksoy (Kalite)',
        { delivery: 5, quality: 5, commercial: 4, customerService: 5, ohsEmergency: 5 },
        'ISO 9001 ve İSG denetimi tam puanla tamamlandı.'
      ),
      makeEval(
        'ev-1001-3',
        '2026-07-14',
        '2026 Q2',
        'Selin Aksoy (Kalite)',
        { delivery: 4, quality: 5, commercial: 4, customerService: 4, ohsEmergency: 5 },
        'Sevkiyat planlama uyumu artırıldı.'
      ),
      makeEval(
        'ev-1001-2',
        '2026-04-12',
        '2026 Q1',
        'Murat Kaya (Satın Alma)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'İlk çeyrek denetiminde A sınırına yakın istikrarlı performans.'
      ),
      makeEval(
        'ev-1001-1',
        '2025-12-19',
        '2025 Q4',
        'Murat Kaya (Satın Alma)',
        { delivery: 3, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Yıl sonu teslimat yoğunluğu nedeniyle termin takibi önerildi.'
      ),
    ],
    createdAt: '2025-03-14',
    updatedAt: '2026-10-18',
    notes: 'Ana sac ve alüminyum profil tedarikçisi.',
  },
  {
    id: 'sup-1002',
    code: 'TDR-1002',
    name: 'Marmara Oluklu Ambalaj Çözümleri Ltd. Şti.',
    taxNumber: '6120487231',
    taxOffice: 'Beylikdüzü V.D.',
    category: 'Ambalaj & Baskı',
    classification: 'Onaylı',
    city: 'İstanbul',
    address: 'Beylikdüzü OSB 3. Cad. No:28 İstanbul',
    contactPerson: 'Zeynep Yıldız',
    emails: ['zeynep@marmaraambalaj.com'],
    phone: '+90 212 875 42 10',
    scores: { delivery: 4, quality: 5, commercial: 4, customerService: 5, ohsEmergency: 4 },
    evaluations: [
      makeEval(
        'ev-1002-3',
        '2026-10-05',
        '2026 Q3',
        'Burak Şahin (Lojistik)',
        { delivery: 4, quality: 5, commercial: 4, customerService: 5, ohsEmergency: 4 },
        'Acil sevkiyatlarda 48 saat içinde ek üretim sağlandı.'
      ),
      makeEval(
        'ev-1002-2',
        '2026-06-22',
        '2026 Q2',
        'Burak Şahin (Lojistik)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Baskı renk tutarlılığı iyileştirildi.'
      ),
      makeEval(
        'ev-1002-1',
        '2026-03-18',
        '2026 Q1',
        'Selin Aksoy (Kalite)',
        { delivery: 3, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 3 },
        'Paletleme ve İSG etiketleme kontrolleri tamamlandı.'
      ),
    ],
    createdAt: '2025-05-20',
    updatedAt: '2026-10-05',
  },
  {
    id: 'sup-1003',
    code: 'TDR-1003',
    name: 'Ege Ekspres Lojistik ve Gümrükleme A.Ş.',
    taxNumber: '3280194405',
    taxOffice: 'Hasan Tahsin V.D.',
    category: 'Lojistik & Nakliye',
    classification: 'Kritik',
    city: 'İzmir',
    address: 'Kemalpaşa OSB Ankara Asfaltı No:82 İzmir',
    contactPerson: 'Hakan Özkan',
    emails: ['hakan.ozkan@egeekspres.com.tr', 'operasyon@egeekspres.com.tr'],
    phone: '+90 232 441 90 12',
    scores: { delivery: 3, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
    evaluations: [
      makeEval(
        'ev-1003-3',
        '2026-09-29',
        '2026 Q3',
        'Burak Şahin (Lojistik)',
        { delivery: 3, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Liman yoğunluğu kaynaklı iki sevkiyatta 1 günlük gecikme yaşandı.'
      ),
      makeEval(
        'ev-1003-2',
        '2026-06-15',
        '2026 Q2',
        'Burak Şahin (Lojistik)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 5, ohsEmergency: 4 },
        'Gümrük evrak süreçlerinde tam zamanlı koordinasyon sağlandı.'
      ),
      makeEval(
        'ev-1003-1',
        '2026-02-27',
        '2026 Q1',
        'Murat Kaya (Satın Alma)',
        { delivery: 4, quality: 4, commercial: 3, customerService: 4, ohsEmergency: 4 },
        'Navlun endeksi güncellemesi sözleşme sınırlarında kaldı.'
      ),
    ],
    createdAt: '2025-01-11',
    updatedAt: '2026-09-29',
  },
  {
    id: 'sup-1004',
    code: 'TDR-1004',
    name: 'Bursa Otomasyon ve Rulman Sistemleri San. Tic.',
    taxNumber: '1930448120',
    taxOffice: 'Nilüfer V.D.',
    category: 'Makine & Yedek Parça',
    classification: 'Kritik',
    city: 'Bursa',
    address: 'NOSAB 204. Sok. No:12 Nilüfer / Bursa',
    contactPerson: 'Emre Çelik',
    emails: ['emre.celik@bursaotomasyon.com'],
    phone: '+90 224 243 11 08',
    scores: { delivery: 5, quality: 5, commercial: 4, customerService: 4, ohsEmergency: 5 },
    evaluations: [
      makeEval(
        'ev-1004-3',
        '2026-10-11',
        '2026 Q3',
        'Ahmet Tunç (Bakım)',
        { delivery: 5, quality: 5, commercial: 4, customerService: 4, ohsEmergency: 5 },
        'Orijinal yedek parça garantisi ve hızlı teknik destek.'
      ),
      makeEval(
        'ev-1004-2',
        '2026-07-02',
        '2026 Q2',
        'Ahmet Tunç (Bakım)',
        { delivery: 4, quality: 5, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Planlı bakım duruşu için kritik stok hazır tutuldu.'
      ),
      makeEval(
        'ev-1004-1',
        '2026-03-11',
        '2026 Q1',
        'Murat Kaya (Satın Alma)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Dönem içi fiyat sabitleme protokolü yenilendi.'
      ),
    ],
    createdAt: '2025-02-02',
    updatedAt: '2026-10-11',
  },
  {
    id: 'sup-1005',
    code: 'TDR-1005',
    name: 'Kuzey Bulut Bilişim Teknolojileri A.Ş.',
    taxNumber: '5980231178',
    taxOffice: 'Maslak V.D.',
    category: 'Bilişim & Yazılım',
    classification: 'Onaylı',
    city: 'İstanbul',
    address: 'Büyükdere Cad. Teknopark Plaza Kat:7 Sarıyer / İstanbul',
    contactPerson: 'Derya Aydın',
    emails: ['derya@kuzeybulut.io', 'destek@kuzeybulut.io'],
    phone: '+90 212 310 77 65',
    scores: { delivery: 5, quality: 5, commercial: 3, customerService: 5, ohsEmergency: 4 },
    evaluations: [
      makeEval(
        'ev-1005-2',
        '2026-10-20',
        '2026 Q3',
        'Murat Kaya (Satın Alma)',
        { delivery: 5, quality: 5, commercial: 3, customerService: 5, ohsEmergency: 4 },
        'SLA hedefleri eksiksiz karşılandı.'
      ),
      makeEval(
        'ev-1005-1',
        '2026-05-19',
        '2026 Q2',
        'Murat Kaya (Satın Alma)',
        { delivery: 4, quality: 4, commercial: 3, customerService: 4, ohsEmergency: 4 },
        'Lisans yenileme sürecinde destek yanıt süreleri hızlandı.'
      ),
    ],
    createdAt: '2025-04-19',
    updatedAt: '2026-10-20',
  },
  {
    id: 'sup-1006',
    code: 'TDR-1006',
    name: 'Trakya Endüstriyel Kimya ve Solvent Tic. Ltd.',
    taxNumber: '8590112944',
    taxOffice: 'Çorlu V.D.',
    category: 'Kimyasal & Sarf Malzeme',
    classification: 'Onaylı',
    city: 'Tekirdağ',
    address: 'Velimeşe OSB 1. Yol No:45 Ergene / Tekirdağ',
    contactPerson: 'Serkan Yavuz',
    emails: ['serkan@trakyakimya.com.tr', 'kalite@trakyakimya.com.tr'],
    phone: '+90 282 651 30 99',
    scores: { delivery: 3, quality: 2, commercial: 3, customerService: 3, ohsEmergency: 2 },
    evaluations: [
      makeEval(
        'ev-1006-3',
        '2026-09-14',
        '2026 Q3',
        'Selin Aksoy (Kalite)',
        { delivery: 3, quality: 2, commercial: 3, customerService: 3, ohsEmergency: 2 },
        'MSDS güvenlik bilgi formlarında gecikme ve 2 partide yoğunluk sapması.'
      ),
      makeEval(
        'ev-1006-2',
        '2026-05-11',
        '2026 Q2',
        'Selin Aksoy (Kalite)',
        { delivery: 3, quality: 3, commercial: 4, customerService: 3, ohsEmergency: 3 },
        'Kimyasal sızdırmazlık ambalaj uyarısı iletildi.'
      ),
      makeEval(
        'ev-1006-1',
        '2026-01-22',
        '2026 Q1',
        'Burak Şahin (Lojistik)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 3, ohsEmergency: 4 },
        'İlk dönem sevkiyatları standartlara uygun gerçekleşti.'
      ),
    ],
    createdAt: '2025-06-01',
    updatedAt: '2026-09-14',
    notes: 'DİF açıldı, 3 aylık yakın izleme sürecinde.',
  },
  {
    id: 'sup-1007',
    code: 'TDR-1007',
    name: 'Başkent Enerji ve Pano Bakım Hizmetleri Ltd.',
    taxNumber: '1480775210',
    taxOffice: 'Ostim V.D.',
    category: 'Enerji & Bakım Hizmetleri',
    classification: 'Onaylı',
    city: 'Ankara',
    address: 'Ostim OSB 100. Yıl Bulvarı No:64 Yenimahalle / Ankara',
    contactPerson: 'Onur Koç',
    emails: ['onur.koc@baskentenerji.com'],
    phone: '+90 312 385 60 22',
    scores: { delivery: 4, quality: 4, commercial: 4, customerService: 3, ohsEmergency: 4 },
    evaluations: [
      makeEval(
        'ev-1007-3',
        '2026-10-02',
        '2026 Q3',
        'Ahmet Tunç (Bakım)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 3, ohsEmergency: 4 },
        'Trafo periyodik bakımları İSG kurallarına uygun tamamlandı.'
      ),
      makeEval(
        'ev-1007-2',
        '2026-06-09',
        '2026 Q2',
        'Ahmet Tunç (Bakım)',
        { delivery: 4, quality: 4, commercial: 3, customerService: 3, ohsEmergency: 4 },
        'Yedek ekipman temin süresi 1 gün iyileşti.'
      ),
      makeEval(
        'ev-1007-1',
        '2026-02-15',
        '2026 Q1',
        'Murat Kaya (Satın Alma)',
        { delivery: 3, quality: 4, commercial: 3, customerService: 3, ohsEmergency: 4 },
        'Bakım raporlama formatı standartlaştırıldı.'
      ),
    ],
    createdAt: '2025-07-23',
    updatedAt: '2026-10-02',
  },
  {
    id: 'sup-1008',
    code: 'TDR-1008',
    name: 'Akdeniz Etiket ve Ofset Matbaacılık San. Tic.',
    taxNumber: '0340921856',
    taxOffice: 'Kurumlar V.D.',
    category: 'Ambalaj & Baskı',
    classification: 'Aday',
    city: 'Antalya',
    address: 'Antalya OSB 2. Kısım 21. Cad. No:9 Döşemealtı / Antalya',
    contactPerson: 'Elif Arslan',
    emails: ['elif@akdenizetiket.com', 'siparis@akdenizetiket.com'],
    phone: '+90 242 221 44 19',
    scores: { delivery: 3, quality: 4, commercial: 4, customerService: 3, ohsEmergency: 3 },
    evaluations: [
      makeEval(
        'ev-1008-2',
        '2026-10-28',
        '2026 Q4',
        'Murat Kaya (Satın Alma)',
        { delivery: 3, quality: 4, commercial: 4, customerService: 3, ohsEmergency: 3 },
        'Deneme üretimi numuneleri onaylandı, aday tedarikçi izlemesinde.'
      ),
      makeEval(
        'ev-1008-1',
        '2026-09-12',
        '2026 Q3',
        'Selin Aksoy (Kalite)',
        { delivery: 3, quality: 3, commercial: 4, customerService: 3, ohsEmergency: 2 },
        'İlk aday saha değerlendirmesi tamamlandı.'
      ),
    ],
    createdAt: '2026-09-10',
    updatedAt: '2026-10-28',
  },
  {
    id: 'sup-1009',
    code: 'TDR-1009',
    name: 'Karadeniz Döküm ve Bağlantı Elemanları Ltd.',
    taxNumber: '4920631109',
    taxOffice: 'İlkadım V.D.',
    category: 'Hammadde & Metal',
    classification: 'Aday',
    city: 'Samsun',
    address: 'Tekkeköy Organize Sanayi Bölgesi 5. Sok. No:18 Samsun',
    contactPerson: 'Volkan Şen',
    emails: ['volkan@karadenizdokum.com.tr'],
    phone: '+90 362 266 51 30',
    scores: { delivery: 2, quality: 2, commercial: 3, customerService: 2, ohsEmergency: 1 },
    evaluations: [
      makeEval(
        'ev-1009-3',
        '2026-10-15',
        '2026 Q3',
        'Selin Aksoy (Kalite)',
        { delivery: 2, quality: 2, commercial: 3, customerService: 2, ohsEmergency: 1 },
        'Son 3 siparişte yüksek iade oranı ve saha İSG ekipman eksikliği.'
      ),
      makeEval(
        'ev-1009-2',
        '2026-06-15',
        '2026 Q2',
        'Selin Aksoy (Kalite)',
        { delivery: 2, quality: 3, commercial: 3, customerService: 2, ohsEmergency: 2 },
        'Döküm tolerans sapmaları için düzeltici aksiyon talep edildi.'
      ),
      makeEval(
        'ev-1009-1',
        '2026-02-10',
        '2026 Q1',
        'Murat Kaya (Satın Alma)',
        { delivery: 3, quality: 3, commercial: 3, customerService: 3, ohsEmergency: 2 },
        'Deneme siparişi sonrası izleme başlatıldı.'
      ),
    ],
    createdAt: '2025-08-05',
    updatedAt: '2026-10-15',
    notes: 'Yetersiz performans nedeniyle askıya alma değerlendirmesinde.',
  },
  {
    id: 'sup-1010',
    code: 'TDR-1010',
    name: 'Doğuş Pnömatik ve Hidrolik Ekipmanlar A.Ş.',
    taxNumber: '3100845129',
    taxOffice: 'İkitelli V.D.',
    category: 'Makine & Yedek Parça',
    classification: 'Alternatifi Sınırlı',
    city: 'İstanbul',
    address: 'İkitelli OSB Demirciler San. Sit. B Blok No:41 Başakşehir / İstanbul',
    contactPerson: 'Cemil Karahan',
    emails: ['cemil.karahan@doguspnomatik.com', 'teklif@doguspnomatik.com'],
    phone: '+90 212 549 88 15',
    scores: { delivery: 4, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
    evaluations: [
      makeEval(
        'ev-1010-2',
        '2026-10-08',
        '2026 Q3',
        'Ahmet Tunç (Bakım)',
        { delivery: 4, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 4 },
        'Valf ve silindir sevkiyatları eksiksiz teslim edildi.'
      ),
      makeEval(
        'ev-1010-1',
        '2026-05-04',
        '2026 Q2',
        'Ahmet Tunç (Bakım)',
        { delivery: 3, quality: 4, commercial: 4, customerService: 4, ohsEmergency: 3 },
        'Hidrolik hortum teslimatlarında iyileşme kaydedildi.'
      ),
    ],
    createdAt: '2025-04-03',
    updatedAt: '2026-10-08',
  },
];
