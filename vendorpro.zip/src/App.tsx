import { useEffect, useMemo, useState } from 'react';
import { Menu, Plus } from 'lucide-react';
import { AnalyticsView } from './components/AnalyticsView';
import { ExcelImportView } from './components/ExcelImportView';
import { PerformanceScoringView } from './components/PerformanceScoringView';
import { Sidebar } from './components/Sidebar';
import { SupplierDetailDrawer } from './components/SupplierDetailDrawer';
import {
  SupplierFormModal,
  type SupplierFormValues,
} from './components/SupplierFormModal';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { SupplierListView } from './components/SupplierListView';
import { SupplierScoringDrawer } from './components/SupplierScoringDrawer';
import { SupplierHistoryDrawer } from './components/SupplierHistoryDrawer';
import { SEED_SUPPLIERS, SUPPLIER_CATEGORIES } from './data/seedSuppliers';
import type {
  ActiveView,
  DuplicateStrategy,
  ParsedExcelRow,
  Supplier,
  SurveyScores,
} from './types/supplier';
import {
  calculateTotalScore,
  enrichSupplierWithScore,
  generateNextSupplierCode,
  getEvaluationOutcome,
  sortEvaluationsDescending,
} from './utils/supplierLogic';

const STORAGE_SUPPLIERS_KEY = 'r1_suppliers_v2';
const STORAGE_CATEGORIES_KEY = 'r1_supplier_categories_v1';

const VIEW_TITLES: Record<ActiveView, string> = {
  list: 'Tedarikçi Yönetimi',
  scoring: 'Tedarikçi Puanlama Anketi',
  import: 'Excel İçe Aktarım',
  analytics: 'Performans Analitiği',
};

function loadInitialSuppliers(): Supplier[] {
  try {
    const raw = localStorage.getItem(STORAGE_SUPPLIERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const seedById = new Map(SEED_SUPPLIERS.map((s) => [s.id, s]));
        return parsed.map((item: Supplier) => {
          const seedMatch = seedById.get(item.id);
          if (seedMatch && item.updatedAt === seedMatch.updatedAt) {
            return {
              ...item,
              evaluations:
                Array.isArray(item.evaluations) && item.evaluations.length <= 1
                  ? seedMatch.evaluations
                  : item.evaluations,
              classification:
                item.id === 'sup-1010' && item.classification === 'Onaylı'
                  ? seedMatch.classification
                  : item.classification,
            };
          }
          return item;
        });
      }
    }
  } catch {
    // fallback to seed
  }
  return SEED_SUPPLIERS;
}

function loadInitialCategories(initialSuppliers: Supplier[]): string[] {
  const base = new Set<string>(SUPPLIER_CATEGORIES);
  try {
    const raw = localStorage.getItem(STORAGE_CATEGORIES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const cleaned = parsed
          .map((c) => String(c).trim())
          .filter((c) => c.length > 0);
        if (cleaned.length > 0) {
          for (const s of initialSuppliers) {
            if (s.category.trim()) {
              if (!cleaned.some((c) => c.toLocaleLowerCase('tr') === s.category.trim().toLocaleLowerCase('tr'))) {
                cleaned.push(s.category.trim());
              }
            }
          }
          return cleaned;
        }
      }
    }
  } catch {
    // fallback to default
  }
  for (const s of initialSuppliers) {
    if (s.category.trim()) base.add(s.category.trim());
  }
  return Array.from(base);
}

export default function App() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(loadInitialSuppliers);
  const [categories, setCategories] = useState<string[]>(() =>
    loadInitialCategories(loadInitialSuppliers())
  );
  const [activeView, setActiveView] = useState<ActiveView>('list');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [detailSupplierId, setDetailSupplierId] = useState<string | null>(null);
  const [scoringDrawerSupplierId, setScoringDrawerSupplierId] = useState<string | null>(null);
  const [historySupplierId, setHistorySupplierId] = useState<string | null>(null);
  const [scoringPageSupplierId, setScoringPageSupplierId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [categoryManagerOpen, setCategoryManagerOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SUPPLIERS_KEY, JSON.stringify(suppliers));
    } catch {
      // ignore storage quota errors
    }
  }, [suppliers]);

  const enrichedSuppliers = useMemo(
    () => suppliers.map((s) => enrichSupplierWithScore(s)),
    [suppliers]
  );

  const detailSupplier = useMemo(
    () => enrichedSuppliers.find((s) => s.id === detailSupplierId) ?? null,
    [enrichedSuppliers, detailSupplierId]
  );

  const scoringDrawerSupplier = useMemo(
    () => enrichedSuppliers.find((s) => s.id === scoringDrawerSupplierId) ?? null,
    [enrichedSuppliers, scoringDrawerSupplierId]
  );

  const historySupplier = useMemo(
    () => enrichedSuppliers.find((s) => s.id === historySupplierId) ?? null,
    [enrichedSuppliers, historySupplierId]
  );

  const suggestedCode = useMemo(
    () => generateNextSupplierCode(suppliers),
    [suppliers]
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CATEGORIES_KEY, JSON.stringify(categories));
    } catch {
      // ignore storage quota errors
    }
  }, [categories]);

  const ensureCategoryRegistered = (categoryName: string) => {
    const trimmed = categoryName.trim();
    if (!trimmed) return;
    setCategories((prev) => {
      if (prev.some((c) => c.toLocaleLowerCase('tr') === trimmed.toLocaleLowerCase('tr'))) {
        return prev;
      }
      return [...prev, trimmed];
    });
  };

  const handleAddCategory = (name: string): { ok: boolean; error?: string } => {
    const trimmed = name.trim();
    if (!trimmed) {
      return { ok: false, error: 'Kategori adı boş bırakılamaz.' };
    }
    if (categories.some((c) => c.toLocaleLowerCase('tr') === trimmed.toLocaleLowerCase('tr'))) {
      return { ok: false, error: `"${trimmed}" kategorisi zaten mevcut.` };
    }
    setCategories((prev) => [...prev, trimmed]);
    return { ok: true };
  };

  const handleRenameCategory = (
    oldName: string,
    newName: string
  ): { ok: boolean; error?: string } => {
    const trimmed = newName.trim();
    if (!trimmed) {
      return { ok: false, error: 'Yeni kategori adı boş bırakılamaz.' };
    }
    if (
      oldName.toLocaleLowerCase('tr') !== trimmed.toLocaleLowerCase('tr') &&
      categories.some((c) => c.toLocaleLowerCase('tr') === trimmed.toLocaleLowerCase('tr'))
    ) {
      return { ok: false, error: `"${trimmed}" adında başka bir kategori zaten mevcut.` };
    }
    setCategories((prev) => prev.map((c) => (c === oldName ? trimmed : c)));
    setSuppliers((prev) =>
      prev.map((s) => (s.category === oldName ? { ...s, category: trimmed } : s))
    );
    return { ok: true };
  };

  const handleDeleteCategory = (name: string): { ok: boolean; error?: string } => {
    const usedCount = suppliers.filter((s) => s.category === name).length;
    if (usedCount > 0) {
      return {
        ok: false,
        error: `"${name}" kategorisinde ${usedCount} tedarikçi kayıtlı olduğu için silinemez.`,
      };
    }
    if (categories.length <= 1) {
      return { ok: false, error: 'En az bir tedarikçi kategorisi kalmalıdır.' };
    }
    setCategories((prev) => prev.filter((c) => c !== name));
    return { ok: true };
  };

  const handleSaveSupplier = (values: SupplierFormValues, editingId?: string) => {
    const today = new Date().toISOString().slice(0, 10);
    ensureCategoryRegistered(values.category);
    if (editingId) {
      setSuppliers((prev) =>
        prev.map((s) =>
          s.id === editingId
            ? {
                ...s,
                ...values,
                updatedAt: today,
              }
            : s
        )
      );
    } else {
      const newSupplier: Supplier = {
        id: `sup-${Date.now()}`,
        code: values.code,
        name: values.name,
        taxNumber: values.taxNumber,
        taxOffice: values.taxOffice,
        category: values.category,
        classification: values.classification,
        city: values.city,
        address: values.address,
        contactPerson: values.contactPerson,
        emails: values.emails,
        phone: values.phone,
        scores: {
          delivery: 3,
          quality: 3,
          commercial: 3,
          customerService: 3,
          ohsEmergency: 3,
        },
        evaluations: [],
        createdAt: today,
        updatedAt: today,
        notes: values.notes,
      };
      setSuppliers((prev) => [newSupplier, ...prev]);
    }
    setFormOpen(false);
    setEditingSupplier(null);
  };

  const handleDeleteSupplier = (supplierId: string) => {
    setSuppliers((prev) => prev.filter((s) => s.id !== supplierId));
    if (detailSupplierId === supplierId) {
      setDetailSupplierId(null);
    }
  };

  const handleSaveEvaluation = (
    supplierId: string,
    payload: {
      date?: string;
      period: string;
      evaluator: string;
      scores: SurveyScores;
      notes: string;
    }
  ) => {
    const evalDate =
      payload.date && payload.date.trim()
        ? payload.date.trim()
        : new Date().toISOString().slice(0, 10);
    const totalScore = calculateTotalScore(payload.scores);
    const outcome = getEvaluationOutcome(totalScore);

    setSuppliers((prev) =>
      prev.map((s) => {
        if (s.id !== supplierId) return s;
        const newEval = {
          id: `ev-${Date.now()}`,
          date: evalDate,
          period: payload.period,
          evaluator: payload.evaluator,
          scores: { ...payload.scores },
          totalScore,
          tier: outcome.tier,
          resultLabel: outcome.resultLabel,
          actionLabel: outcome.actionLabel,
          notes: payload.notes,
        };
        const sortedEvaluations = sortEvaluationsDescending([
          newEval,
          ...s.evaluations,
        ]);
        const latestEval = sortedEvaluations[0];
        return {
          ...s,
          scores: latestEval ? { ...latestEval.scores } : { ...payload.scores },
          evaluations: sortedEvaluations,
          updatedAt: latestEval ? latestEval.date : evalDate,
        };
      })
    );
  };

  const handleCommitExcelImport = (
    rows: ParsedExcelRow[],
    duplicateStrategy: DuplicateStrategy
  ) => {
    const today = new Date().toISOString().slice(0, 10);
    let added = 0;
    let updated = 0;
    let skipped = 0;

    setSuppliers((prev) => {
      const next = [...prev];
      const workingCodeList = prev.map((s) => ({ code: s.code }));

      for (const row of rows) {
        if (row.status === 'invalid') continue;
        if (row.status === 'duplicate_skipped') {
          skipped += 1;
          continue;
        }
        if (!row.normalized) continue;

        if (
          row.status === 'valid_update' &&
          row.existingSupplierId &&
          duplicateStrategy === 'update'
        ) {
          const idx = next.findIndex((s) => s.id === row.existingSupplierId);
          if (idx !== -1) {
            const current = next[idx];
            next[idx] = {
              ...current,
              code: row.normalized.code || current.code,
              name: row.normalized.name,
              taxOffice: row.normalized.taxOffice,
              category: row.normalized.category,
              classification: row.normalized.classification,
              city: row.normalized.city,
              address: row.normalized.address,
              contactPerson: row.normalized.contactPerson,
              emails:
                row.normalized.emails.length > 0
                  ? row.normalized.emails
                  : current.emails,
              phone: row.normalized.phone,
              scores: row.normalized.scores,
              updatedAt: today,
            };
            updated += 1;
          }
        } else if (row.status === 'valid_new') {
          const nextCode =
            row.normalized.code || generateNextSupplierCode(workingCodeList);
          workingCodeList.push({ code: nextCode });

          const totalScore = calculateTotalScore(row.normalized.scores);
          const outcome = getEvaluationOutcome(totalScore);
          const created: Supplier = {
            id: `sup-${Date.now()}-${row.rowIndex}`,
            code: nextCode,
            name: row.normalized.name,
            taxNumber: row.normalized.taxNumber,
            taxOffice: row.normalized.taxOffice,
            category: row.normalized.category,
            classification: row.normalized.classification,
            city: row.normalized.city,
            address: row.normalized.address,
            contactPerson: row.normalized.contactPerson,
            emails: row.normalized.emails,
            phone: row.normalized.phone,
            scores: row.normalized.scores,
            evaluations: [
              {
                id: `ev-imp-${Date.now()}-${row.rowIndex}`,
                date: today,
                period: 'Excel Aktarımı',
                evaluator: 'Toplu İçe Aktarım',
                scores: row.normalized.scores,
                totalScore,
                tier: outcome.tier,
                resultLabel: outcome.resultLabel,
                actionLabel: outcome.actionLabel,
                notes: 'Excel dosyası üzerinden aktarılan başlangıç anket puanları.',
              },
            ],
            createdAt: today,
            updatedAt: today,
          };
          next.unshift(created);
          added += 1;
        }
      }
      return next;
    });

    for (const row of rows) {
      if (row.normalized && (row.status === 'valid_new' || row.status === 'valid_update')) {
        ensureCategoryRegistered(row.normalized.category);
      }
    }

    return { added, updated, skipped };
  };

  const handleResetDemoData = () => {
    setSuppliers(SEED_SUPPLIERS);
    setCategories(SUPPLIER_CATEGORIES);
    setDetailSupplierId(null);
    setScoringDrawerSupplierId(null);
    setHistorySupplierId(null);
  };

  const openEditById = (supplierId: string) => {
    const found = suppliers.find((s) => s.id === supplierId);
    if (!found) return;
    setEditingSupplier(found);
    setDetailSupplierId(null);
    setFormOpen(true);
  };

  const openScoringInline = (supplierId: string) => {
    setDetailSupplierId(null);
    if (activeView === 'list') {
      setScoringDrawerSupplierId(supplierId);
    } else {
      setScoringPageSupplierId(supplierId);
      setActiveView('scoring');
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      <Sidebar
        activeView={activeView}
        onSelectView={setActiveView}
        supplierCount={suppliers.length}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onResetDemoData={handleResetDemoData}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-3 sm:gap-8 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Gezinme menüsünü aç"
              className="lg:hidden p-2 -ml-2 rounded-lg text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <Menu className="w-5 h-5" />
            </button>
            <nav aria-label="Sayfa yolu" className="flex items-center gap-2 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-500 whitespace-nowrap">
                Tedarikçiler
              </span>
              <span className="hidden sm:inline text-slate-300" aria-hidden="true">
                /
              </span>
              <h1 className="font-semibold text-slate-900 truncate">
                {VIEW_TITLES[activeView]}
              </h1>
            </nav>
          </div>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => {
                setEditingSupplier(null);
                setFormOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Yeni Tedarikçi</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-[1440px] w-full mx-auto">
          {activeView === 'list' && (
            <SupplierListView
              suppliers={enrichedSuppliers}
              categories={categories}
              onSelectSupplier={(id) => setDetailSupplierId(id)}
              onEditSupplier={openEditById}
              onScoreSupplier={(id) => setScoringDrawerSupplierId(id)}
              onOpenHistory={(id) => setHistorySupplierId(id)}
              onOpenCategoryManager={() => setCategoryManagerOpen(true)}
              onGoToImport={() => setActiveView('import')}
              onOpenNewSupplier={() => {
                setEditingSupplier(null);
                setFormOpen(true);
              }}
            />
          )}

          {activeView === 'scoring' && (
            <PerformanceScoringView
              suppliers={enrichedSuppliers}
              initialSupplierId={scoringPageSupplierId}
              onOpenHistory={(id) => setHistorySupplierId(id)}
              onSaveEvaluation={handleSaveEvaluation}
            />
          )}

          {activeView === 'import' && (
            <ExcelImportView
              existingSuppliers={suppliers}
              onCommitImport={handleCommitExcelImport}
              onGoToList={() => setActiveView('list')}
            />
          )}

          {activeView === 'analytics' && (
            <AnalyticsView
              suppliers={enrichedSuppliers}
              onSelectSupplier={(id) => setDetailSupplierId(id)}
              onScoreSupplier={openScoringInline}
            />
          )}
        </main>
      </div>

      <SupplierDetailDrawer
        supplier={detailSupplier}
        onClose={() => setDetailSupplierId(null)}
        onEdit={(sup) => {
          setEditingSupplier(sup);
          setDetailSupplierId(null);
          setFormOpen(true);
        }}
        onDelete={handleDeleteSupplier}
        onScore={openScoringInline}
        onOpenHistory={(id) => {
          setDetailSupplierId(null);
          setHistorySupplierId(id);
        }}
      />

      <SupplierScoringDrawer
        supplier={scoringDrawerSupplier}
        onClose={() => setScoringDrawerSupplierId(null)}
        onOpenHistory={(id) => setHistorySupplierId(id)}
        onSaveEvaluation={handleSaveEvaluation}
      />

      <SupplierHistoryDrawer
        supplier={historySupplier}
        suppliers={enrichedSuppliers}
        onSelectSupplierId={(id) => setHistorySupplierId(id)}
        onClose={() => setHistorySupplierId(null)}
        onScoreSupplier={openScoringInline}
      />

      <SupplierFormModal
        open={formOpen}
        editingSupplier={editingSupplier}
        suggestedCode={suggestedCode}
        existingSuppliers={suppliers}
        categories={categories}
        onClose={() => {
          setFormOpen(false);
          setEditingSupplier(null);
        }}
        onSave={handleSaveSupplier}
      />

      <CategoryManagerModal
        open={categoryManagerOpen}
        categories={categories}
        suppliers={suppliers}
        onClose={() => setCategoryManagerOpen(false)}
        onAddCategory={handleAddCategory}
        onRenameCategory={handleRenameCategory}
        onDeleteCategory={handleDeleteCategory}
      />
    </div>
  );
}
