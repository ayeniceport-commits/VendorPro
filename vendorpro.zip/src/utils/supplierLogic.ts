import type {
  ColumnMapping,
  CriterionKey,
  DuplicateStrategy,
  EvaluationOutcome,
  ExcelFieldKey,
  ParsedExcelRow,
  PerformanceEvaluation,
  PerformanceTier,
  SortDirection,
  SortField,
  Supplier,
  SupplierClassification,
  SupplierWithScore,
  SurveyScores,
} from '../types/supplier';

export const SURVEY_CRITERIA: Array<{
  key: CriterionKey;
  order: number;
  label: string;
  question: string;
}> = [
  {
    key: 'delivery',
    order: 1,
    label: 'Zamanında Teslimat',
    question: 'Siparişler belirlenen termin tarihine ve miktarına uygun şekilde teslim ediliyor mu?',
  },
  {
    key: 'quality',
    order: 2,
    label: 'Kalite Uygunluğu',
    question: 'Teslim edilen ürün/hizmet teknik şartname ve kalite standartlarını karşılıyor mu?',
  },
  {
    key: 'commercial',
    order: 3,
    label: 'Ticari Uyum',
    question: 'Fiyat istikrarı, faturalandırma doğruluğu ve sözleşme koşullarına uyum sağlanıyor mu?',
  },
  {
    key: 'customerService',
    order: 4,
    label: 'Müşteri Hizmetleri',
    question: 'İletişim hızı, teknik destek ve uygunsuzluklara geri dönüş performansı yeterli mi?',
  },
  {
    key: 'ohsEmergency',
    order: 5,
    label: 'İSG-Acil Durum Uygunluğu',
    question: 'İş sağlığı ve güvenliği kuralları ile acil durum prosedürlerine uyum sağlanıyor mu?',
  },
];

export const RATING_SCALE_LABELS: Record<number, string> = {
  1: 'Yetersiz',
  2: 'Zayıf',
  3: 'Orta',
  4: 'İyi',
  5: 'Mükemmel',
};

export const EVALUATION_SCALE_TABLE: EvaluationOutcome[] = [
  {
    tier: 'A',
    rangeLabel: '21 – 25',
    resultLabel: 'Mükemmel',
    actionLabel: 'Yıllık gözden geçirme',
    textColor: 'text-emerald-700',
  },
  {
    tier: 'B',
    rangeLabel: '16 – 20',
    resultLabel: 'İyi',
    actionLabel: '6 aylık izleme',
    textColor: 'text-blue-700',
  },
  {
    tier: 'C',
    rangeLabel: '11 – 15',
    resultLabel: 'Gelişim Gerekli',
    actionLabel: 'DİF + 3 aylık izleme',
    textColor: 'text-amber-700',
  },
  {
    tier: 'D',
    rangeLabel: '≤ 10',
    resultLabel: 'Yetersiz',
    actionLabel: 'Askıya alma',
    textColor: 'text-red-700',
  },
];

export const CLASSIFICATION_OPTIONS: SupplierClassification[] = [
  'Kritik',
  'Alternatifi Sınırlı',
  'Onaylı',
  'Aday',
];

export const CLASSIFICATION_TEXT_COLOR: Record<SupplierClassification, string> = {
  Kritik: 'text-amber-800',
  'Alternatifi Sınırlı': 'text-purple-700',
  Onaylı: 'text-emerald-700',
  Aday: 'text-blue-700',
};

export const EXCEL_FIELD_DEFINITIONS: Array<{
  key: ExcelFieldKey;
  label: string;
  required: boolean;
  aliases: string[];
}> = [
  {
    key: 'code',
    label: 'Tedarikçi Kodu',
    required: false,
    aliases: ['tedarikci kodu', 'tedarikci_kodu', 'kod', 'code', 'supplier code', 'cari kodu'],
  },
  {
    key: 'name',
    label: 'Firma Unvanı',
    required: true,
    aliases: ['firma unvani', 'firma adi', 'tedarikci adi', 'unvan', 'company name', 'name', 'supplier', 'tedarikci'],
  },
  {
    key: 'taxNumber',
    label: 'Vergi No / TCKN',
    required: true,
    aliases: ['vergi no', 'vergi numarasi', 'vkn', 'tckn', 'tax number', 'tax id', 'vergi_no'],
  },
  {
    key: 'taxOffice',
    label: 'Vergi Dairesi',
    required: false,
    aliases: ['vergi dairesi', 'tax office', 'vergi_dairesi'],
  },
  {
    key: 'category',
    label: 'Kategori',
    required: false,
    aliases: ['kategori', 'sektor', 'alan', 'category', 'grup'],
  },
  {
    key: 'classification',
    label: 'Sınıflandırma (Kritik/Alternatifi Sınırlı/Onaylı/Aday)',
    required: false,
    aliases: ['siniflandirma', 'tedarikci sinifi', 'tedarikci tipi', 'sinif', 'tip', 'classification'],
  },
  {
    key: 'city',
    label: 'Şehir',
    required: false,
    aliases: ['sehir', 'il', 'city', 'lokasyon'],
  },
  {
    key: 'address',
    label: 'Adres',
    required: false,
    aliases: ['adres', 'acik adres', 'address', 'lokasyon adresi'],
  },
  {
    key: 'contactPerson',
    label: 'Yetkili Kişi',
    required: false,
    aliases: ['yetkili', 'yetkili kisi', 'yetkili adi', 'contact', 'contact person', 'ilgili kisi'],
  },
  {
    key: 'emails',
    label: 'E-posta Adresleri',
    required: false,
    aliases: ['e-posta', 'e-posta adresleri', 'eposta', 'email', 'emails', 'mail', 'e posta'],
  },
  {
    key: 'phone',
    label: 'Yetkili Telefon',
    required: false,
    aliases: ['telefon', 'yetkili telefon', 'tel', 'gsm', 'phone'],
  },
  {
    key: 'delivery',
    label: 'Zamanında Teslimat (1-5)',
    required: false,
    aliases: ['zamaninda teslimat', 'teslimat', 'teslimat puani', 'delivery'],
  },
  {
    key: 'quality',
    label: 'Kalite Uygunluğu (1-5)',
    required: false,
    aliases: ['kalite uygunlugu', 'kalite', 'kalite puani', 'quality'],
  },
  {
    key: 'commercial',
    label: 'Ticari Uyum (1-5)',
    required: false,
    aliases: ['ticari uyum', 'ticari', 'fiyat', 'commercial'],
  },
  {
    key: 'customerService',
    label: 'Müşteri Hizmetleri (1-5)',
    required: false,
    aliases: ['musteri hizmetleri', 'iletisim', 'musteri', 'customer service'],
  },
  {
    key: 'ohsEmergency',
    label: 'İSG-Acil Durum Uygunluğu (1-5)',
    required: false,
    aliases: ['isg-acil durum uygunlugu', 'isg', 'acil durum', 'isg uygunlugu', 'ohs'],
  },
];

export function clampCriterionScore(value: number): number {
  if (!Number.isFinite(value)) return 1;
  return Math.min(5, Math.max(1, Math.round(value)));
}

export function calculateTotalScore(scores: SurveyScores): number {
  return (
    clampCriterionScore(scores.delivery) +
    clampCriterionScore(scores.quality) +
    clampCriterionScore(scores.commercial) +
    clampCriterionScore(scores.customerService) +
    clampCriterionScore(scores.ohsEmergency)
  );
}

export function getPerformanceTier(totalScore: number): PerformanceTier {
  if (totalScore >= 21) return 'A';
  if (totalScore >= 16) return 'B';
  if (totalScore >= 11) return 'C';
  return 'D';
}

export function getEvaluationOutcome(totalScore: number): EvaluationOutcome {
  const tier = getPerformanceTier(totalScore);
  return EVALUATION_SCALE_TABLE.find((row) => row.tier === tier) ?? EVALUATION_SCALE_TABLE[3];
}

export function enrichSupplierWithScore(supplier: Supplier): SupplierWithScore {
  const totalScore = calculateTotalScore(supplier.scores);
  const outcome = getEvaluationOutcome(totalScore);
  return {
    ...supplier,
    totalScore,
    tier: outcome.tier,
    outcome,
  };
}

export function normalizeTurkishText(input: string): string {
  return input
    .trim()
    .replace(/İ/g, 'i')
    .replace(/I/g, 'i')
    .toLowerCase()
    .replace(/\u0307/g, '')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ş/g, 's')
    .replace(/ı/g, 'i')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/\s+/g, ' ');
}

export function autoDetectColumnMapping(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {};
  const normalizedHeaders = headers.map((h) => ({
    original: h,
    normalized: normalizeTurkishText(h).replace(/[()]/g, ''),
  }));

  for (const field of EXCEL_FIELD_DEFINITIONS) {
    const exact = normalizedHeaders.find((h) => field.aliases.includes(h.normalized));
    if (exact) {
      mapping[field.key] = exact.original;
      continue;
    }
    const partial = normalizedHeaders.find((h) =>
      field.aliases.some((alias) => h.normalized.includes(alias) || alias.includes(h.normalized))
    );
    if (partial && !Object.values(mapping).includes(partial.original)) {
      mapping[field.key] = partial.original;
    }
  }

  return mapping;
}

export function normalizeSupplierClassification(
  rawValue: unknown
): SupplierClassification | null {
  if (rawValue === undefined || rawValue === null || String(rawValue).trim() === '') {
    return 'Onaylı';
  }
  const s = normalizeTurkishText(String(rawValue));
  if (['kritik', 'critical', 'stratejik'].includes(s)) return 'Kritik';
  if (
    [
      'alternatifi sinirli',
      'alternatif sinirli',
      'sinirli alternatif',
      'limited alternative',
      'tek kaynak',
      'alternatifi_sinirli',
    ].includes(s)
  ) {
    return 'Alternatifi Sınırlı';
  }
  if (['onayli', 'approved', 'aktif'].includes(s)) return 'Onaylı';
  if (['aday', 'candidate', 'potansiyel'].includes(s)) return 'Aday';
  return null;
}

export function parseNumericCell(value: unknown): number | null {
  if (value === undefined || value === null || String(value).trim() === '') return null;
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  const cleaned = String(value).trim().replace(',', '.');
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function parseMultiEmails(raw: string): { valid: string[]; invalid: string[] } {
  if (!raw || !raw.trim()) return { valid: [], invalid: [] };
  const parts = raw
    .split(/[;,\n]+/)
    .map((item) => item.trim())
    .filter((item) => item.length > 0);

  const seen = new Set<string>();
  const valid: string[] = [];
  const invalid: string[] = [];

  for (const part of parts) {
    const lower = part.toLowerCase();
    if (seen.has(lower)) continue;
    seen.add(lower);
    if (isValidEmail(part)) {
      valid.push(part);
    } else {
      invalid.push(part);
    }
  }
  return { valid, invalid };
}

export function isValidTaxNumber(taxNumber: string): boolean {
  const digits = taxNumber.replace(/\s+/g, '');
  return /^\d{10,11}$/.test(digits);
}

export function generateNextSupplierCode(existingSuppliers: Array<{ code: string }>): string {
  let maxNumber = 1000;
  for (const s of existingSuppliers) {
    const match = /^TDR-(\d+)$/i.exec(s.code.trim());
    if (match) {
      const n = Number(match[1]);
      if (Number.isFinite(n) && n > maxNumber) {
        maxNumber = n;
      }
    }
  }
  return `TDR-${maxNumber + 1}`;
}

export function parseExcelRows(
  rawRows: Array<Record<string, unknown>>,
  mapping: ColumnMapping,
  existingSuppliers: Supplier[],
  duplicateStrategy: DuplicateStrategy
): ParsedExcelRow[] {
  const existingByTax = new Map<string, Supplier>();
  for (const supplier of existingSuppliers) {
    existingByTax.set(supplier.taxNumber.replace(/\s+/g, ''), supplier);
  }

  const seenTaxInFile = new Set<string>();

  const getVal = (row: Record<string, unknown>, key: ExcelFieldKey): string => {
    const colName = mapping[key];
    if (!colName) return '';
    const v = row[colName];
    if (v === undefined || v === null) return '';
    return String(v).trim();
  };

  return rawRows.map((raw, idx) => {
    const rowIndex = idx + 2;
    const errors: string[] = [];

    const name = getVal(raw, 'name');
    const taxNumberRaw = getVal(raw, 'taxNumber').replace(/\s+/g, '');
    const code = getVal(raw, 'code');
    const taxOffice = getVal(raw, 'taxOffice') || 'Belirtilmedi';
    const category = getVal(raw, 'category') || 'Genel Tedarik';
    const classificationRaw = mapping.classification ? raw[mapping.classification] : undefined;
    const city = getVal(raw, 'city') || 'İstanbul';
    const address = getVal(raw, 'address') || '-';
    const contactPerson = getVal(raw, 'contactPerson') || '-';
    const emailsRaw = getVal(raw, 'emails');
    const phone = getVal(raw, 'phone') || '-';

    if (!name) {
      errors.push('Firma Unvanı zorunludur.');
    }
    if (!taxNumberRaw) {
      errors.push('Vergi No zorunludur.');
    } else if (!isValidTaxNumber(taxNumberRaw)) {
      errors.push('Vergi No 10 veya 11 haneli rakamlardan oluşmalıdır.');
    }

    const emailParse = parseMultiEmails(emailsRaw);
    if (emailParse.invalid.length > 0) {
      errors.push(`Geçersiz e-posta adresi: ${emailParse.invalid.join(', ')}.`);
    }

    const classification = normalizeSupplierClassification(classificationRaw);
    if (!classification) {
      errors.push(
        `Geçersiz sınıflandırma: "${String(classificationRaw)}" (Kritik, Alternatifi Sınırlı, Onaylı veya Aday olmalıdır).`
      );
    }

    const parseSurveyField = (key: keyof SurveyScores, label: string, defaultVal: number): number => {
      const col = mapping[key];
      if (!col) return defaultVal;
      const cellVal = raw[col];
      if (cellVal === undefined || cellVal === null || String(cellVal).trim() === '') {
        return defaultVal;
      }
      const parsed = parseNumericCell(cellVal);
      if (parsed === null || parsed < 1 || parsed > 5) {
        errors.push(`${label} 1 ile 5 arasında olmalıdır.`);
        return defaultVal;
      }
      return clampCriterionScore(parsed);
    };

    const scores: SurveyScores = {
      delivery: parseSurveyField('delivery', 'Zamanında Teslimat', 3),
      quality: parseSurveyField('quality', 'Kalite Uygunluğu', 3),
      commercial: parseSurveyField('commercial', 'Ticari Uyum', 3),
      customerService: parseSurveyField('customerService', 'Müşteri Hizmetleri', 3),
      ohsEmergency: parseSurveyField('ohsEmergency', 'İSG-Acil Durum Uygunluğu', 3),
    };

    if (taxNumberRaw && seenTaxInFile.has(taxNumberRaw)) {
      errors.push('Dosya içinde mükerrer Vergi No.');
    }
    if (taxNumberRaw) {
      seenTaxInFile.add(taxNumberRaw);
    }

    if (errors.length > 0) {
      return {
        rowIndex,
        raw,
        status: 'invalid',
        errors,
      };
    }

    const existing = existingByTax.get(taxNumberRaw);
    const normalized = {
      code: code || undefined,
      name,
      taxNumber: taxNumberRaw,
      taxOffice,
      category,
      classification: classification || 'Onaylı',
      city,
      address,
      contactPerson,
      emails: emailParse.valid,
      phone,
      scores,
    };

    if (existing) {
      if (duplicateStrategy === 'skip') {
        return {
          rowIndex,
          raw,
          status: 'duplicate_skipped',
          errors: [],
          normalized,
          existingSupplierId: existing.id,
        };
      }
      return {
        rowIndex,
        raw,
        status: 'valid_update',
        errors: [],
        normalized,
        existingSupplierId: existing.id,
      };
    }

    return {
      rowIndex,
      raw,
      status: 'valid_new',
      errors: [],
      normalized,
    };
  });
}

export interface SupplierFilterOptions {
  search: string;
  category: string;
  classification: string;
  tier: string;
  sortField: SortField;
  sortDirection: SortDirection;
}

export function filterAndSortSuppliers(
  suppliers: SupplierWithScore[],
  options: SupplierFilterOptions
): SupplierWithScore[] {
  const q = normalizeTurkishText(options.search);

  const filtered = suppliers.filter((s) => {
    if (options.category && options.category !== 'ALL' && s.category !== options.category) {
      return false;
    }
    if (
      options.classification &&
      options.classification !== 'ALL' &&
      s.classification !== options.classification
    ) {
      return false;
    }
    if (options.tier && options.tier !== 'ALL' && s.tier !== options.tier) {
      return false;
    }
    if (q) {
      const haystacks = [
        s.name,
        s.code,
        s.taxNumber,
        s.category,
        s.classification,
        s.city,
        s.address,
        s.contactPerson,
        ...s.emails,
      ];
      const matches = haystacks.some((item) => normalizeTurkishText(item).includes(q));
      if (!matches) return false;
    }
    return true;
  });

  const dir = options.sortDirection === 'asc' ? 1 : -1;
  return [...filtered].sort((a, b) => {
    switch (options.sortField) {
      case 'totalScore':
        return (a.totalScore - b.totalScore) * dir;
      case 'code':
        return a.code.localeCompare(b.code, 'tr') * dir;
      case 'category':
        return a.category.localeCompare(b.category, 'tr') * dir;
      case 'classification':
        return a.classification.localeCompare(b.classification, 'tr') * dir;
      case 'updatedAt':
        return a.updatedAt.localeCompare(b.updatedAt) * dir;
      case 'name':
      default:
        return a.name.localeCompare(b.name, 'tr') * dir;
    }
  });
}

export interface AnalyticsSummary {
  totalSuppliers: number;
  classificationCounts: Record<SupplierClassification, number>;
  averageTotalScore: number;
  tierCounts: Record<PerformanceTier, number>;
  criterionAverages: Record<CriterionKey, number>;
  categoryStats: Array<{
    category: string;
    count: number;
    averageScore: number;
    topSupplierName: string;
  }>;
  actionRequiredList: SupplierWithScore[];
  topPerformers: SupplierWithScore[];
}

export function computeAnalyticsSummary(suppliers: SupplierWithScore[]): AnalyticsSummary {
  const totalSuppliers = suppliers.length;
  const classificationCounts: Record<SupplierClassification, number> = {
    Kritik: 0,
    'Alternatifi Sınırlı': 0,
    Onaylı: 0,
    Aday: 0,
  };

  const tierCounts: Record<PerformanceTier, number> = { A: 0, B: 0, C: 0, D: 0 };
  const criterionTotals: Record<CriterionKey, number> = {
    delivery: 0,
    quality: 0,
    commercial: 0,
    customerService: 0,
    ohsEmergency: 0,
  };

  let totalScoreSum = 0;
  const categoryBuckets = new Map<string, SupplierWithScore[]>();

  for (const s of suppliers) {
    classificationCounts[s.classification] += 1;
    tierCounts[s.tier] += 1;
    totalScoreSum += s.totalScore;
    criterionTotals.delivery += s.scores.delivery;
    criterionTotals.quality += s.scores.quality;
    criterionTotals.commercial += s.scores.commercial;
    criterionTotals.customerService += s.scores.customerService;
    criterionTotals.ohsEmergency += s.scores.ohsEmergency;

    const bucket = categoryBuckets.get(s.category) ?? [];
    bucket.push(s);
    categoryBuckets.set(s.category, bucket);
  }

  const averageTotalScore =
    totalSuppliers > 0 ? Math.round((totalScoreSum / totalSuppliers) * 10) / 10 : 0;

  const criterionAverages: Record<CriterionKey, number> = {
    delivery: totalSuppliers > 0 ? Math.round((criterionTotals.delivery / totalSuppliers) * 10) / 10 : 0,
    quality: totalSuppliers > 0 ? Math.round((criterionTotals.quality / totalSuppliers) * 10) / 10 : 0,
    commercial: totalSuppliers > 0 ? Math.round((criterionTotals.commercial / totalSuppliers) * 10) / 10 : 0,
    customerService:
      totalSuppliers > 0 ? Math.round((criterionTotals.customerService / totalSuppliers) * 10) / 10 : 0,
    ohsEmergency:
      totalSuppliers > 0 ? Math.round((criterionTotals.ohsEmergency / totalSuppliers) * 10) / 10 : 0,
  };

  const categoryStats = Array.from(categoryBuckets.entries())
    .map(([category, items]) => {
      const avg = items.reduce((sum, item) => sum + item.totalScore, 0) / items.length;
      const top = [...items].sort((a, b) => b.totalScore - a.totalScore)[0];
      return {
        category,
        count: items.length,
        averageScore: Math.round(avg * 10) / 10,
        topSupplierName: top?.name ?? '-',
      };
    })
    .sort((a, b) => b.averageScore - a.averageScore);

  const actionRequiredList = [...suppliers]
    .filter((s) => s.tier === 'C' || s.tier === 'D')
    .sort((a, b) => a.totalScore - b.totalScore);

  const topPerformers = [...suppliers]
    .filter((s) => s.tier === 'A' || s.tier === 'B')
    .sort((a, b) => b.totalScore - a.totalScore)
    .slice(0, 5);

  return {
    totalSuppliers,
    classificationCounts,
    averageTotalScore,
    tierCounts,
    criterionAverages,
    categoryStats,
    actionRequiredList,
    topPerformers,
  };
}

export interface ScoreProgressionSummary {
  count: number;
  chronological: PerformanceEvaluation[];
  latest: PerformanceEvaluation | null;
  previous: PerformanceEvaluation | null;
  deltaFromPrevious: number | null;
  deltaFromFirst: number | null;
  averageScore: number;
  minScore: number;
  maxScore: number;
  trendDirection: 'up' | 'down' | 'flat' | 'single' | 'empty';
}

export function sortEvaluationsChronologically(
  evaluations: PerformanceEvaluation[]
): PerformanceEvaluation[] {
  return [...evaluations].sort((a, b) => {
    const dateCmp = a.date.localeCompare(b.date);
    if (dateCmp !== 0) return dateCmp;
    return a.period.localeCompare(b.period, 'tr');
  });
}

export function sortEvaluationsDescending(
  evaluations: PerformanceEvaluation[]
): PerformanceEvaluation[] {
  return [...evaluations].sort((a, b) => {
    const dateCmp = b.date.localeCompare(a.date);
    if (dateCmp !== 0) return dateCmp;
    return b.period.localeCompare(a.period, 'tr');
  });
}

export function computeScoreProgression(
  evaluations: PerformanceEvaluation[]
): ScoreProgressionSummary {
  if (evaluations.length === 0) {
    return {
      count: 0,
      chronological: [],
      latest: null,
      previous: null,
      deltaFromPrevious: null,
      deltaFromFirst: null,
      averageScore: 0,
      minScore: 0,
      maxScore: 0,
      trendDirection: 'empty',
    };
  }

  const chronological = sortEvaluationsChronologically(evaluations);
  const latest = chronological[chronological.length - 1];
  const first = chronological[0];
  const previous = chronological.length >= 2 ? chronological[chronological.length - 2] : null;

  const scores = chronological.map((ev) => ev.totalScore);
  const sum = scores.reduce((acc, val) => acc + val, 0);
  const averageScore = Math.round((sum / scores.length) * 10) / 10;
  const minScore = Math.min(...scores);
  const maxScore = Math.max(...scores);

  const deltaFromPrevious = previous ? latest.totalScore - previous.totalScore : null;
  const deltaFromFirst = chronological.length >= 2 ? latest.totalScore - first.totalScore : null;

  let trendDirection: ScoreProgressionSummary['trendDirection'] = 'single';
  if (deltaFromPrevious !== null) {
    if (deltaFromPrevious > 0) trendDirection = 'up';
    else if (deltaFromPrevious < 0) trendDirection = 'down';
    else trendDirection = 'flat';
  }

  return {
    count: chronological.length,
    chronological,
    latest,
    previous,
    deltaFromPrevious,
    deltaFromFirst,
    averageScore,
    minScore,
    maxScore,
    trendDirection,
  };
}

export function formatShortTrDate(isoDate: string): string {
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  return `${parts[2]}.${parts[1]}.${parts[0]}`;
}
