import * as XLSX from 'xlsx';
import type { SupplierWithScore } from '../types/supplier';

export interface ExcelWorkbookData {
  fileName: string;
  sheetNames: string[];
  sheets: Record<
    string,
    {
      headers: string[];
      rows: Array<Record<string, unknown>>;
    }
  >;
}

export async function readExcelFile(file: File): Promise<ExcelWorkbookData> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  const sheets: ExcelWorkbookData['sheets'] = {};

  for (const sheetName of workbook.SheetNames) {
    const worksheet = workbook.Sheets[sheetName];
    const jsonRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, {
      defval: '',
      raw: false,
    });

    const headerMatrix = XLSX.utils.sheet_to_json<unknown[]>(worksheet, {
      header: 1,
      defval: '',
    });
    const firstRow = Array.isArray(headerMatrix[0]) ? headerMatrix[0] : [];
    const headers = firstRow
      .map((cell) => String(cell ?? '').trim())
      .filter((h) => h.length > 0);

    sheets[sheetName] = {
      headers:
        headers.length > 0
          ? headers
          : jsonRows.length > 0
          ? Object.keys(jsonRows[0])
          : [],
      rows: jsonRows,
    };
  }

  return {
    fileName: file.name,
    sheetNames: workbook.SheetNames,
    sheets,
  };
}

export function downloadSupplierExcelTemplate(): void {
  const sampleRows = [
    {
      'Tedarikçi Kodu': 'TDR-1011',
      'Firma Unvanı': 'Örnek Lojistik ve Depolama A.Ş.',
      'Vergi No': '7410258963',
      'Vergi Dairesi': 'Kadıköy V.D.',
      Kategori: 'Lojistik & Nakliye',
      Sınıflandırma: 'Kritik',
      Şehir: 'İstanbul',
      Adres: 'Tuzla OSB 4. Cad. No:22 Tuzla / İstanbul',
      'Yetkili Kişi': 'Ayşe Yılmaz',
      'E-posta Adresleri': 'ayse@orneklojistik.com; operasyon@orneklojistik.com',
      'Yetkili Telefon': '+90 216 412 30 50',
      'Zamanında Teslimat': 5,
      'Kalite Uygunluğu': 4,
      'Ticari Uyum': 4,
      'Müşteri Hizmetleri': 5,
      'İSG-Acil Durum Uygunluğu': 4,
    },
    {
      'Tedarikçi Kodu': 'TDR-1012',
      'Firma Unvanı': 'Örnek Endüstriyel Ambalaj Ltd. Şti.',
      'Vergi No': '8520369741',
      'Vergi Dairesi': 'Nilüfer V.D.',
      Kategori: 'Ambalaj & Baskı',
      Sınıflandırma: 'Aday',
      Şehir: 'Bursa',
      Adres: 'Hasanağa OSB 7. Sok. No:15 Nilüfer / Bursa',
      'Yetkili Kişi': 'Mehmet Demir',
      'E-posta Adresleri': 'mehmet@ornekambalaj.com.tr',
      'Yetkili Telefon': '+90 224 311 22 44',
      'Zamanında Teslimat': 4,
      'Kalite Uygunluğu': 4,
      'Ticari Uyum': 3,
      'Müşteri Hizmetleri': 3,
      'İSG-Acil Durum Uygunluğu': 4,
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleRows);
  worksheet['!cols'] = [
    { wch: 15 },
    { wch: 36 },
    { wch: 14 },
    { wch: 18 },
    { wch: 24 },
    { wch: 14 },
    { wch: 14 },
    { wch: 38 },
    { wch: 18 },
    { wch: 40 },
    { wch: 18 },
    { wch: 20 },
    { wch: 18 },
    { wch: 14 },
    { wch: 20 },
    { wch: 24 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Tedarikciler');
  XLSX.writeFile(workbook, 'tedarikci_aktarim_sablonu.xlsx');
}

export function exportSuppliersToExcel(suppliers: SupplierWithScore[]): void {
  const rows = suppliers.map((s) => ({
    'Tedarikçi Kodu': s.code,
    'Firma Unvanı': s.name,
    'Vergi No': s.taxNumber,
    'Vergi Dairesi': s.taxOffice,
    Kategori: s.category,
    Sınıflandırma: s.classification,
    Şehir: s.city,
    Adres: s.address,
    'Yetkili Kişi': s.contactPerson,
    'E-posta Adresleri': s.emails.join('; '),
    'Yetkili Telefon': s.phone,
    'Zamanında Teslimat': s.scores.delivery,
    'Kalite Uygunluğu': s.scores.quality,
    'Ticari Uyum': s.scores.commercial,
    'Müşteri Hizmetleri': s.scores.customerService,
    'İSG-Acil Durum Uygunluğu': s.scores.ohsEmergency,
    'Toplam Puan (25)': s.totalScore,
    Derece: s.tier,
    'Değerlendirme Sonucu': s.outcome.resultLabel,
    Aksiyon: s.outcome.actionLabel,
    'Son Güncelleme': s.updatedAt,
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet['!cols'] = [
    { wch: 14 },
    { wch: 38 },
    { wch: 14 },
    { wch: 18 },
    { wch: 24 },
    { wch: 14 },
    { wch: 14 },
    { wch: 38 },
    { wch: 18 },
    { wch: 40 },
    { wch: 18 },
    { wch: 18 },
    { wch: 18 },
    { wch: 14 },
    { wch: 18 },
    { wch: 24 },
    { wch: 16 },
    { wch: 8 },
    { wch: 18 },
    { wch: 24 },
    { wch: 14 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Tedarikciler');
  const today = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `tedarikci_performans_listesi_${today}.xlsx`);
}
