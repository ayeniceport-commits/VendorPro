import test from 'node:test';
import assert from 'node:assert/strict';
import {
  autoDetectColumnMapping,
  calculateTotalScore,
  computeAnalyticsSummary,
  computeScoreProgression,
  enrichSupplierWithScore,
  filterAndSortSuppliers,
  formatShortTrDate,
  generateNextSupplierCode,
  getEvaluationOutcome,
  getPerformanceTier,
  parseExcelRows,
  parseMultiEmails,
  sortEvaluationsChronologically,
  sortEvaluationsDescending,
} from './supplierLogic';
import { SEED_SUPPLIERS } from '../data/seedSuppliers';

test('calculateTotalScore sums 5 criteria out of 25', () => {
  const score = calculateTotalScore({
    delivery: 5,
    quality: 4,
    commercial: 4,
    customerService: 5,
    ohsEmergency: 3,
  });
  assert.equal(score, 21);
});

test('getPerformanceTier and getEvaluationOutcome map 25-point boundaries accurately', () => {
  assert.equal(getPerformanceTier(25), 'A');
  assert.equal(getPerformanceTier(21), 'A');
  assert.equal(getEvaluationOutcome(21).resultLabel, 'Mükemmel');
  assert.equal(getEvaluationOutcome(21).actionLabel, 'Yıllık gözden geçirme');

  assert.equal(getPerformanceTier(20), 'B');
  assert.equal(getPerformanceTier(16), 'B');
  assert.equal(getEvaluationOutcome(18).resultLabel, 'İyi');
  assert.equal(getEvaluationOutcome(18).actionLabel, '6 aylık izleme');

  assert.equal(getPerformanceTier(15), 'C');
  assert.equal(getPerformanceTier(11), 'C');
  assert.equal(getEvaluationOutcome(13).resultLabel, 'Gelişim Gerekli');
  assert.equal(getEvaluationOutcome(13).actionLabel, 'DİF + 3 aylık izleme');

  assert.equal(getPerformanceTier(10), 'D');
  assert.equal(getPerformanceTier(5), 'D');
  assert.equal(getEvaluationOutcome(10).resultLabel, 'Yetersiz');
  assert.equal(getEvaluationOutcome(10).actionLabel, 'Askıya alma');
});

test('parseMultiEmails splits, deduplicates, and validates multiple email addresses', () => {
  const res = parseMultiEmails('ali@firma.com; veli@firma.com, ALI@firma.com, gecersiz');
  assert.deepEqual(res.valid, ['ali@firma.com', 'veli@firma.com']);
  assert.deepEqual(res.invalid, ['gecersiz']);
});

test('autoDetectColumnMapping maps Turkish Excel headers including survey criteria, classification, and address', () => {
  const headers = [
    'Tedarikçi Kodu',
    'Firma Unvanı',
    'Vergi No',
    'Kategori',
    'Sınıflandırma',
    'Şehir',
    'Adres',
    'Yetkili Kişi',
    'E-posta Adresleri',
    'Yetkili Telefon',
    'Zamanında Teslimat',
    'Kalite Uygunluğu',
    'Ticari Uyum',
    'Müşteri Hizmetleri',
    'İSG-Acil Durum Uygunluğu',
  ];
  const mapping = autoDetectColumnMapping(headers);
  assert.equal(mapping.code, 'Tedarikçi Kodu');
  assert.equal(mapping.name, 'Firma Unvanı');
  assert.equal(mapping.taxNumber, 'Vergi No');
  assert.equal(mapping.classification, 'Sınıflandırma');
  assert.equal(mapping.address, 'Adres');
  assert.equal(mapping.emails, 'E-posta Adresleri');
  assert.equal(mapping.delivery, 'Zamanında Teslimat');
  assert.equal(mapping.quality, 'Kalite Uygunluğu');
  assert.equal(mapping.commercial, 'Ticari Uyum');
  assert.equal(mapping.customerService, 'Müşteri Hizmetleri');
  assert.equal(mapping.ohsEmergency, 'İSG-Acil Durum Uygunluğu');
});

test('parseExcelRows validates 1-5 survey scores, multi-emails, and classifications', () => {
  const existing = SEED_SUPPLIERS.slice(0, 1);
  const mapping = {
    name: 'Firma Unvanı',
    taxNumber: 'Vergi No',
    classification: 'Sınıflandırma',
    address: 'Adres',
    emails: 'E-posta Adresleri',
    delivery: 'Zamanında Teslimat',
  };

  const rawRows = [
    {
      'Firma Unvanı': 'Yeni Tedarikçi A.Ş.',
      'Vergi No': '9988776655',
      Sınıflandırma: 'Kritik',
      Adres: 'İkitelli OSB No:10',
      'E-posta Adresleri': 'a@yeni.com; b@yeni.com',
      'Zamanında Teslimat': '5',
    },
    {
      'Firma Unvanı': 'Hatalı Puanlı Firma',
      'Vergi No': '1122334455',
      Sınıflandırma: 'Bilinmeyen',
      'E-posta Adresleri': 'yanlis-mail',
      'Zamanında Teslimat': '8',
    },
  ];

  const parsed = parseExcelRows(rawRows, mapping, existing, 'update');
  assert.equal(parsed[0].status, 'valid_new');
  assert.equal(parsed[0].normalized?.classification, 'Kritik');
  assert.deepEqual(parsed[0].normalized?.emails, ['a@yeni.com', 'b@yeni.com']);
  assert.equal(parsed[0].normalized?.scores.delivery, 5);

  assert.equal(parsed[1].status, 'invalid');
  assert.ok(parsed[1].errors.length >= 3);
});

test('generateNextSupplierCode and filterAndSortSuppliers work on updated model', () => {
  assert.equal(generateNextSupplierCode([{ code: 'TDR-1010' }]), 'TDR-1011');

  const enriched = SEED_SUPPLIERS.map((s) => enrichSupplierWithScore(s));
  const kritikOnly = filterAndSortSuppliers(enriched, {
    search: '',
    category: 'ALL',
    classification: 'Kritik',
    tier: 'ALL',
    sortField: 'totalScore',
    sortDirection: 'desc',
  });
  assert.ok(kritikOnly.length >= 1);
  assert.ok(kritikOnly.every((s) => s.classification === 'Kritik'));

  const summary = computeAnalyticsSummary(enriched);
  assert.equal(summary.totalSuppliers, SEED_SUPPLIERS.length);
  assert.ok(summary.averageTotalScore > 10 && summary.averageTotalScore <= 25);
});

test('computeScoreProgression sorts evaluations chronologically and computes deltas', () => {
  const supplier = SEED_SUPPLIERS[0]; // Anadolu Hassas Metal: 19 -> 20 -> 22 -> 24
  const progression = computeScoreProgression(supplier.evaluations);
  assert.equal(progression.count, 4);
  assert.equal(progression.chronological[0].period, '2025 Q4');
  assert.equal(progression.chronological[3].period, '2026 Q3');
  assert.equal(progression.latest?.totalScore, 24);
  assert.equal(progression.previous?.totalScore, 22);
  assert.equal(progression.deltaFromPrevious, 2);
  assert.equal(progression.deltaFromFirst, 5);
  assert.equal(progression.minScore, 19);
  assert.equal(progression.maxScore, 24);
  assert.equal(progression.trendDirection, 'up');

  const desc = sortEvaluationsDescending(sortEvaluationsChronologically(supplier.evaluations));
  assert.equal(desc[0].date, '2026-10-18');
  assert.equal(formatShortTrDate('2026-10-18'), '18.10.2026');

  const declining = computeScoreProgression(SEED_SUPPLIERS[5].evaluations); // Trakya Kimya: 19 -> 16 -> 13
  assert.equal(declining.deltaFromPrevious, -3);
  assert.equal(declining.deltaFromFirst, -6);
  assert.equal(declining.trendDirection, 'down');

  const empty = computeScoreProgression([]);
  assert.equal(empty.count, 0);
  assert.equal(empty.trendDirection, 'empty');
});

test('normalizeSupplierClassification and parseExcelRows support Alternatifi Sınırlı', () => {
  const parsed = parseExcelRows(
    [
      {
        'Firma Unvanı': 'Özel Valf A.Ş.',
        'Vergi No': '7766554433',
        Sınıflandırma: 'Alternatifi Sınırlı',
        Kategori: 'Özel Hidrolik',
      },
    ],
    {
      name: 'Firma Unvanı',
      taxNumber: 'Vergi No',
      classification: 'Sınıflandırma',
      category: 'Kategori',
    },
    [],
    'update'
  );
  assert.equal(parsed[0].status, 'valid_new');
  assert.equal(parsed[0].normalized?.classification, 'Alternatifi Sınırlı');
  assert.equal(parsed[0].normalized?.category, 'Özel Hidrolik');

  const summary = computeAnalyticsSummary(SEED_SUPPLIERS.map((s) => enrichSupplierWithScore(s)));
  assert.ok(summary.classificationCounts['Alternatifi Sınırlı'] >= 1);
});
